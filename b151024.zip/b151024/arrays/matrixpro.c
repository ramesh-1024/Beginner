#include<stdio.h>
void main()
{
	int a[i][j],b[i][j],c[i][j],i,j,k,m1,m2,n1,n2 
	printf("enter the no.of rows and columns of the first matrix:\n");
	scanf("%d %d",&m1,&n1);
	printf("enter the elements:\n");
	for(i=0;i<m1;i++)
	{
		for(j=0;j<n1;j++)
		scanf("%d",&a[i][j]);
		printf("\n");
	}
	printf("enter the no.of  rows and columns of second matrix:\n");
	scanf("%d %d",&m2,&n2);
	printf("enter the elements:\n");
	for(i=0;i<m2;i++)
	{
		for(j=0;j<n2;j++)
		scanf("%d",b[i][j]);
		printf("\n");
	}
	if(m1==n2)
		{
		printf("we can perfom product for the given matrices:\n");
		for(i=0;i<m1;i++)
		{
			for(j=0;j<n2;j++)
			{
			c[i][j]=0;
			for(k=0;k<n1;k++)
			c[i][j]=c[i][j]+a[i][k]*b[k][j];
			}
		}
		for(i=0;i<m1;i++)
		{
			for(j=0;j<n2;j++)
			{
				printf("%d\t",c[i][j]);
			}printf("\n")
		}
	}
	else
	printf("we cannot perform multiplication");
}
