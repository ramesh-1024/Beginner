#include<stdio.h>
void main()
{	 int a[100],i,n,k,c;
	printf("enter the number of numbers u want");
	scanf("%d",&n);
	printf("enter the numbers");
	
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("primes are");
	for(i=0;i<n;i++)
	{
		c=0;
		 for(k=1;k<=a[i];k++)
		{ 
			if(a[i]%k==0)
		c++;
		}
	if(c==2)
	printf("%d\n",a[i]);
	}

}


