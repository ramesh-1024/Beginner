#include<stdio.h>
void main()
{	int n,sum=0,r,k;
printf("enter a number to know whether palindrome");
scanf("%d",&n);
k=n;
	while(n>0)
		{	 r=n%10;

			sum=sum*10 + r;
	
			n=n/10;
		}
if(k==sum)
printf("then %d is palindrome",k);
else
printf("%d is not palindrome",k);

}
