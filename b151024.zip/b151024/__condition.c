#include<stdio.h>
void main()
{ int a,b;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
a>b?printf("%d is big",a):printf("%d is big",b);
}
