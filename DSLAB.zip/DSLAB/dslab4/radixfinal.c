#include<stdio.h>
//radix sort
void main()
{
	int rad[10][10],a[10],t[10],n,i,j,d=1,num,max,k,c=0,m,x;
	printf("enter the size of array:\n");
	scanf("%d",&n);
	printf("enter the values\n");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	max=a[0];
	for(i=0;i<n;i++)
	{
		if(max>a[i])
		max=a[i];
	}
	while(max>0)
	{
		c++;
		max=max/10;
	}
	m=c;
	for(k=0;k<m;k++)
	{
		for(j=0;j<10;j++)
		{
			t[j]=0;
		}
		for(i=0;i<n;i++)
		{
			num=((a[i]/d)%10);
		    rad[num][t[num]++]=a[i];	
		}	
		i=0;
		for(j=0;j<10;j++)
		{
			for(x=0;x<t[j];x++)
			{
			  a[i++]=rad[j][x];
			}
		}
	d=d*10;  
	}
	for(i=0;i<n;i++)
	printf("\n%d\t",a[i]);
}
