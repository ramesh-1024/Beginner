#include<stdio.h>
#include<stdlib.h>
int f=-1,r=-1,q[100];
void qinsert(int s,int n)
{
	int data,i;
	if(r==s-1)
	{
		printf("queue is overflow\n");
		//exit(1);
	}	
	else
	 q[++r]=n;
	if(f==-1)
	 f++;
}
int qdelete()
{

	if(f==-1||f>r)
	{
		printf("queue is under flow\n");
 		//exit(1);
	}
	else
	   return q[f++];
}
void qdisplay()
{
	int i;	
	for(i=f;i<=r;i++)
	printf("%d\t",q[i]);
}
	
int main()
{
	int op,n,s,y;
	printf("enter the size of queue\n");
	scanf("%d",&s);
	do
	{
	printf("\nOPERATIONS ON QUEUE\n");
	printf("1.insert\n2.delete\n3.display\n4.exit\n choose an option\n");
	scanf("%d",&op);
	switch(op)
		{
			case 1:
				printf("Enter the size of queue\n");
				scanf("%d",&n);
				qinsert(s,n);
				break;
		case 2:
				y=qdelete();
				printf("\nDeleted element is %d\n",y);
				break;
		case 3:
				qdisplay();
				break;
		case 4:
				printf("Thanks for using queue\n");
				break;
		default:
				printf("Invalid option.....better luck next time(from 1-3)\n");
			
		}
	}while(op!=4);
return 0;	
}
