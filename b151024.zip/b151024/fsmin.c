#include<stdio.h>
void main()/*Wednesday 16 August 2017 11:16:43 AM IST*/
  { int a,b,k,fmin,smin;
	printf("enter the numbers");
		scanf("%d",&a);
		scanf("%d",&b);
	if(a<b)
	{	fmin=a;
		smin=b;
	}
	else
	{ 	fmin=b;
		smin=a;
	}
		do
		{ 	scanf("%d",&k);
			
			if(k<fmin && k!=-1)
			{ 	smin=fmin;
				fmin=k;
			}
				
			else
				{ if(k<smin && k!=-1)
				smin=k;			
				}
		}
	while(k!=-1);
printf("first min=%d and second min=%d",fmin,smin);
  }

