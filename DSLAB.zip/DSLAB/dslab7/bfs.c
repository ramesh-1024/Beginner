#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
//breadth first search
struct vertex
{
	char ch;
	bool visit;
};
int k=5;
int r= -1,q[50]; 
int f= -1; 
int qelecount=0;

struct vertex *vertices[50];
int adjmat[20][20],vcount=0;

void enq(char data)
{
	q[++r]=data;
	qelecount++;
}
int deq()
{
	qelecount--;
	return q[++f];
}
bool isqempty()
{
	return qelecount==0;
}
void create(char ch)
{
	struct vertex *v;
	v=(struct vertex *)malloc(sizeof(struct vertex));
	v->ch=ch;
	v->visit=0;
	vertices[vcount++]=v;	
}

void addlink(int p,int r)
{
	adjmat[p][r]=1;
	adjmat[r][p]=1;
}

void display(int i)
{
	printf("\n%c\n",vertices[i]->ch);
}

int getvertex(int i)
{
	int j;
	for(j=0;j<vcount;j++)
	{
		if(adjmat[i][j]==1 && vertices[i]->visit==false)
		return i;
	}
	return -1;
}

void bfs() 
{ 
   int i,temp; 
   vertices[0]->visit =true;
   display(0);     
   enq(0); 
   int unvisitedVertex; 
 
   while(!isqempty()) 
   {  
      int temp=deq();    
  
      while((unvisitedVertex=getvertex(temp))!=-1)
	{     
         vertices[unvisitedVertex]->visit=true; 
         display(unvisitedVertex); 
         enq(unvisitedVertex);                
      } 
   
   }             
   for(i = 0;i<vcount;i++) 
   { 
      vertices[i]->visit=false; 
   }     
} 
 
void main() 
{ 
   int i,j,k,M,m,n,p,r;
   char ch;  
   for(i=0;i<k;i++) 
   { 
   	   for(j=0;j<k;j++) 
         adjmat[i][j] = 0;   
   }
   for(m=0;m<k;m++)
   {
   		printf("enter the characters to add\n");
   		scanf("%c",&ch);
  		create(ch);
	}
	printf("enter the no.of links to create\n");
	scanf("%d",&n);
	for(M=0;M<n;M++)
	{
		scanf("%d",&p);
		scanf("%d",&r);
	}
	printf("Breadth First Search is\n");
	bfs();
}

