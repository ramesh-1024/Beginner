#include <stdio.h>
main()
{  int a,b,c;
a=90462;
b=67790;
c=a+b;
printf("the sum of %d and %d is %d",a,b,c);}
