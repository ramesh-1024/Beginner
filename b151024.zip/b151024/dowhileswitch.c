#include<stdio.h>
void main()
{ int a,b,c,d,e,f;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
do
	{
	printf("1.ADDITION\n2.PRODUCT\n3.SUBTRACTION\n4.DIVISION\n5.MODULUS\n6.EXIT\n	");
	printf("enter a option you want");
	scanf("%d",&e);
	 switch(e)
		{		 case 1:
				d=a+b;
				printf("%d\n",d);
				break;
				case 2:
				d=a*b;	
				printf("%d\n",d);
				break;
				case 3:
				d=a-b;
				printf("%d\n",d);
				break;
				case 4:
				d=a/b;
				printf("%d\n",d);
				break;
				case 5:
				d=a%b;
				printf("%d\nt",d);
				break;
				case 6:
				printf("thank you :)...@try again\n");
				default:
				printf("invalid option\n	");
		}}
	while(e!=6);
	
	}
