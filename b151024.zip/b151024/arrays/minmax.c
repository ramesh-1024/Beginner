#include<stdio.h>
void main()
{ int a[100],n,i,j,k,m,smin,fmin,fmax,smax;
	printf("enter a number for how many no.s u want from array:");
	scanf("%d",&n);
	printf("enter the numbers:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	if(a[0]<a[1])
	{ 
		fmin=a[0];
		smin=a[1];
		fmax=a[1];
		smax=a[0];
	}
	else
	{
		fmin=a[1];
		smin=a[0];
		fmax=a[0];
		smin=a[1];
	}
			
	for(i=2;i<n;i++)
	{   
		if(a[i]<fmin)
		{ 
			smin=fmin;
			fmin=a[i];
		}
		else
		{ 
			if (a[i]<smin)
			smin=a[i];
		}
		if(a[i]>fmax)
		{
			smax=fmax;
			fmax=a[i];	
		}	
		else
		{
			if(a[i]>smax)
			smax=a[i];	
		}
	}	

	printf("fmin=%d and smin=%d\n",fmin,smin);
	printf("fmax=%d and smax=%d",fmax,smax);
}
