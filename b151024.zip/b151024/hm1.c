#include<stdio.h>
void main()
{ int n,c,m,k;
printf("enter any number");
scanf("%d",&n);
for(m=1;m<=n;m++)
	{ 	
		c=0;		
		for(k=1;k<=m;k++)
			{ if (m%k==0)
				c++;
			}
	if(c==2)
	printf("%d\n",m);
	
}


}
