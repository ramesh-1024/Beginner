#include<stdio.h>
/*INSERTION SORTING*/
void main()
{ 
	int a[100],n,i,j,t,g,c=0,k=0;
	printf("enter the number of values of from the array:\n");
	scanf("%d",&n);
	printf("enter the values:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=1;i<n;i++)
	{
		j=i;
		while(j>0 && a[j]<a[j-1])
		{
			t=a[j];
			a[j]=a[j-1];
			a[j-1]=t;
			j--;
		}
		printf("\nPass %d\t:",++c);
		for(g=0;g<n;g++)
		printf("%d\t",a[g]);
	}
	printf("\nNo.of comparisions==%d\n",i);
	printf("\nSorting is done :\n");
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
	//printf("\nNo.of swaps==%d\n",k);

}
