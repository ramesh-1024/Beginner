#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *lchild,*rchild;
};
struct node *root=NULL,*nw;
struct node* create(int n)
      { 
		struct node*	temp=(struct node*)malloc(sizeof(struct node));
			temp->data=n;
			temp->lchild=NULL;
			temp->rchild=NULL;
			return(temp);
     } 	
struct node* insert(struct node* node,int n)
{
		if(node==NULL)
		     return create(n);
		else	if(n > node->data)
			node->rchild=insert(node->rchild,n);
		else if(n < node->data)
			node->lchild=insert(node->lchild,n);
		else
		printf("\nDUPLICATE DATA\n");
		return node;
}
void preorder(struct node *root)
{
	if(root)
	{
	printf("%d\n",root->data);
	preorder(root->lchild);
	preorder(root->rchild);
	}
}

void inorder(struct node *root)
{
	if(root)
	{
	inorder(root->lchild);
	printf("%d\n",root->data);
	inorder(root->rchild);
	}
}

void postorder(struct node *root)
{
	if(root)
	{	
	postorder(root->lchild);
	postorder(root->rchild);
	printf("%d\n",root->data);
	}
}
void display(struct node *root)
{
	if(root)
	{
	printf("%d\t",root->data);
	display(root->lchild);
	display(root->rchild);
	}
}
struct node* search(struct node *root,int ele)
{
	int c=0;
	if(root==NULL)
		printf("element not found\n");
	else
	{
		if(root->data==ele)
		{
			printf("element found\n.%d==%d",root->data,ele);
			 return root;
		}
		else
		{
			if (ele > root->data)
			 search(root->rchild,ele);
			else 
			 search(root->lchild,ele);	
		}
	}		
}
struct node * minValueNode(struct node* node)
{
    struct node* p= node;
    while (p->rchild != NULL)
        p = p->rchild;
    return p;
}
struct node* deleteNode(struct node* root, int k)
{
    if (root == NULL) 
     return root;
    if (k < root->data)
        root->lchild = deleteNode(root->lchild, k);
    else if (k > root->data)
        root->rchild = deleteNode(root->rchild, k);
    else
    {
    	printf("%d\n",root->data);
        if (root->lchild == NULL)
        {
            struct node *temp = root->rchild;
            free(root);
            return temp;
        }
        else if (root->rchild == NULL)
        {
            struct node *temp = root->lchild;
            free(root);
            return temp;
        }
        else
	   {
	        struct node* temp = minValueNode(root->rchild);
	        root->data = temp->data;
	        root->rchild = deleteNode(root->rchild, temp->data);
   	   }
    return root;
}
}
 struct node* max(struct node *root)
 {
 	struct node*temp=root;
 	while(temp->rchild!=NULL)
 		temp=temp->rchild;
 	return temp;
 }
void main()
{
	int n,op,ele,k;
	do
	{
		printf("\nChoose an option:\n1.Insert\n2.Preorder\n3.Inorder\n4.Postorder\n5.Dispaly\n6.Search\n7.Delete\n.8.Max.\n9.exit\n");
		scanf("%d",&op);
	switch(op)
	{
		case 1:
				printf("enter the data\n");
				scanf("%d",&n);
				root=insert(root,n);
			break;
		case 2:
			preorder(root);
			break;
		case 3:
			inorder(root);
			break;
		case 4:
			postorder(root);
			break;
		case 5:
			display(root);
			break;
		case 6:		
			printf("enter the element to search\n");
			scanf("%d",&ele);
			search(root,ele);
			break;
		case 7:
			printf("enter the element to delete\n");
			scanf("%d",&k);
			root=deleteNode(root,k);
			break;
		case 8:
			root=max(root);
			printf("%d\tmax is max\n",root->data);
			break;
		case 9:
			printf("tq\n");
			exit(0);
		default:
			printf("enter a valid option\n");
		
	}
}while(op!=9);
}
