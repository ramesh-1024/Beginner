#include<stdio.h>
int top=-1,top2=-1,temp;
char s[20],p[30];
/*void push(char ch)
{
	s[++top]=ch;
	temp=top;
	printf("data p//ushed successfully\n");
}*/

char pop()
{
	
	return s[temp--];
}
 void pushtwo(int k)
 {
 	p[++top2]=k;
 	//printf("pushed second time successfully\n");
 }

int main()
{
	int n,f=0,i;
	char ch,y;
	printf("enter the word:\n");
	scanf("%s",s);
	for(i=0;s[i]!='\0';i++)
	top=i;
	temp=top;
	//printf("\t%d",top);
	while(1)
	{
		y=pop();
		//printf("\t%c\t ",y);
		pushtwo(y);
		if(temp<0)
		break;	
	}
	while(top>=0)	
	{
		if(s[top]!=p[top2])
		{
				f=1;
			printf("\n%c\t%c\n",s[top],p[top2]);
		}
		top--;
		top2--;
	}
	if(f==1)
	printf("word is not a palindrome\n");
	else
	printf("word is a palindrome\n");
	return 0;
}

