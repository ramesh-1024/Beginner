#include<stdio.h>
int read(int n)
{	int k,r,f=0,s=1;
	
	printf("enter number:\n");
	scanf("%d",&n);	
	printf("%d\t%d\t",f,s);
		do
			{ 
				k=0;
				r=f+s;		
				f=s;
				s=r;
				k++;
			}
		while(k<n);
		printf("%d\t",k);
  }

void main()
{ 	int n;
	read(n);
	
}

