#include<stdio.h>
void main()
{ int n,f=0,s=1,r,k;
	printf("fiboacci series less than n");
	scanf("%d",&n);	
	printf("%d\t%d",f,s);
		do
			{ k=0;
				r=f+s;		
				f=s;
				s=r;
				k++;
			}
		while(k<n);
printf("%d\t",k);
}
