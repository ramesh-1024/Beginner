#include<stdio.h>
void main()
{ int i,n,b=0;
printf("enter any number");
scanf("%d",&n);
for(i=1;i<=n;i++)
	
	if(n%i==0)
	{
	b++;
	printf("%d\n",i);

	}
if(b==2)
printf("%d is prime",n);
else
printf("%d is not prime",n);

}
