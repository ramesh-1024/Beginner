#include<stdio.h>
void main()
{	 int a[100],i,n,max=-99999999,min=99999999;
		printf("enter the number for how many variables u want");
		scanf("%d",&n);
	printf("enter the numbers");			
		for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	
	for(i=0;i<n;i++)
	{ 		
		if(a[i]>max)
			max=a[i];
		else if(a[i]<min)
			min=a[i];	
	}

	
printf("max=%d\t",max);
printf("min=%d\t",min);
}
		
		
		
