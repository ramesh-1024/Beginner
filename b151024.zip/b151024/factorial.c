#include<stdio.h>
void main()
{	int n,p=1;
	printf("enter the number to get its factorial value");
	scanf("%d",&n);
	while(n>0)
	{ 	p=p*n;
		n=n-1;
	}
	
	printf("%d\n",p);
}
