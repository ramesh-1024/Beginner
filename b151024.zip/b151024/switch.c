#include<stdio.h>
void main()
{ 
int a,b,c,e;
	printf("enter any two numbers");
scanf("%d %d",&a,&b);
	printf("1.ADDITION\n2.SUBTRACTION\n3.PRODUCT\n4.DIVISION\n5.MODULUS\n Choose any one of the option");
	scanf("%d",&e);
switch(e)
	{ 	

	case 1:
	c=a+b;
	printf("the addition of %d and %d is %d",a,b,c);
break;
	case 2:
	c=a-b;
	printf("the subtraction of %d and %d is %d",a,b,c);
break;
        case 3:
	c=a*b;
	printf("the product of %d and %d is %d",a,b,c);
break;
        case 4:
	c=a/b;
	printf("the division of %d and %d is %d",a,b,c);
break;
        case 5:
	c=a%b;
	printf("the modulus of %d and %d is %d",a,b,c);
break;
		default:
		printf("invalid option");
	}
}
