#include<stdio.h>
main()
{int a,b,c;
scanf("%d %d ",&a,&b);
if(b!=0)
c=a/b;
else 
printf("the denominator is zero",a,b,c);}
