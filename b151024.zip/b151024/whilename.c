#include<stdio.h>
void main()
{ int c=0;
while(c<20)
	{ printf("ramesh\n");
	c=c+1;
	}
}
