#include<stdio.h>
void main()
{ int a,b,c;
 printf("enter any three numbers");
scanf("%d %d %d",&a,&b,&c);
if(a>b)
	{ if (a<c)
	printf("%d is middle",a);
	else	
		{ if (b<c)
		printf("%d is the middle",c);
		else
		printf("%d is the middle",b);
		}
	}
else
	{if (b<c)
	printf("%d is the middle",b);
	else
		{ if(a<c)
		printf("%d is the middle",c);
		else
		printf("%d is the middle",a);
		}
	}
}
