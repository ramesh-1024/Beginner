#include<stdio.h>
void main()
{
	int c=0,n,i=1;
	printf("enter any number");
	scanf("%d",&n);
	while(c<n)
		{ if(i%2==0)
			{	 c++;
				printf("%d\n",i);
			}
		i++;
		}
}
