#include<stdio.h>
void main()
{ int n,f=0,s=1,r;
	printf("fiboacci series less than n");
	scanf("%d",&n);
	printf("%d\t%d",f,s);
		do
			{ r=f+s;		
				printf("\t%d",r);
				f=s;
				s=r;
			}
		while(f+s<n);
}
