#include<stdio.h>
void main()
{ 	int i=10;
	float f=22;
	char c='A';
printf("%d\t %d\t %d\t",sizeof(2562320),sizeof(22.5),sizeof('A'));

}
