#include<stdio.h>
#include<math.h>
void main()
{
	int a[10],s,n,i,j,k,l,x;
	printf("enter the size of hash table\n");
	scanf("%d",&n);
	int h[n];
	for(s=0;s<n;s++)
	h[s]=-1;
	printf("enter the size of array\n");
	scanf("%d",&k);
	printf("enter the values\n");
	for(i=0;i<k;i++)
	scanf("%d",&a[i]);
	for(i=0;i<k;i++)
	{
		j=a[i]%n;
		x=7-(a[i]%7);
		while(1)
		{
			if(h[j]==-1)
			{
				h[j]=a[i];
				break;
			}
			else
			{
				h[j+x]=a[i];
				break;
			}
		}
		printf("\t%d\t%d\n",j,h[j]);	
	}
//	for(j=0;j<n;j++)
	
}
