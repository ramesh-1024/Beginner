#include<stdio.h>
#include<stdlib.h>
void main()
{
	int s[100],n,x,op,k,v,b,pos,m,y,i,top=-1,q,c;
	
	printf("enter the size of array\n");
	scanf("%d",&n);
	printf("enter %d elements\n",n);
	for(i=1;i<=n;i++)	
	{
	top++;
	scanf("%d",&s[top]);
	}
		
	do{
	printf("choose an option:\n1.TO PUSH\n2.TO POP\n3.TO GET PEEK\n4.LENGTH OF STACK\n5.TO PEEP\n6.TO CHANGE\n7.TO DISPLAY\n8.EXIT\n");
	scanf("%d",&op);
	switch(op)
	{
		case 1:
			printf("enter the new data\n");
			scanf("%d",&v);
			s[++top]=v;	
		break;
		case 2:
			printf("%d\n",s[top--]);
		break;
		case 3:
			printf("peek=%d\n",s[top]);
		break;
		case 4:
			m=top;
			printf("length of stack is %d\n",m+1);
		case 5:
				printf("enter at which position's element do u want to find\n");
				scanf("%d",&c);
				if(s[top-c+1]>=0)
				printf("\t%d\n",s[top-c+1]);
		break;
		case 6:
			printf("enter at which position u have to change the value:\n");
			scanf("%d",&pos);
			printf("enter the element:\n");
			scanf("%d",&b);
			s[top-pos+1]=b;
		break;
		case 7:
		for(i=0;i<=top;i++)
			printf("%d\t",s[i]);
		break;
		case 8:
			printf("thank you!!\n");
		break;
		default:
			printf("invalid option:\n");
		
		}
	
	
	}
	while(op!=8);
}
				
				
				
		
		
		
		
		
		
		
		
		
		
		
		
		
		
