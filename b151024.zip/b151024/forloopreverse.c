#include<stdio.h>
void main()
{int i,n;
printf("enter any number");
scanf("%d",&n);
for(i=n;i>=0;i--)
printf("%d\n",i);
}
