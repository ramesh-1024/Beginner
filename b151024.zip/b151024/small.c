#include<stdio.h>
void main()
{
int a,b,c;
printf("my name is ramesh ,,please enter any three numbers");
scanf("%d %d %d",&a,&b,&c);
if(a<b)
{ if(a<c)
printf("%d is smallest",a);
else 
printf("%d  is  smallest",c);
}
else
{ if(b<c)
printf("%d is smallest",b);
else 
printf("%d is smallest",c);}
}
