#include<stdio.h>
void main()
{	 int a[100],b[100],n,i;
	printf("enter the no.of numbers u want:");
	scanf("%d",&n);
	printf("enter the numbers:");
	for(i=0;i<n;i++)
	{	scanf("%d",&a[i]);
		b[i]=a[i];
	
	}
	for(i=0;i<n;i++)
	printf("copied values is=%d\n",b[i]);

}
