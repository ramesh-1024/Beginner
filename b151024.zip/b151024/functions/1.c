#include<stdio.h>

void main()
{
	int a[10],b[10];
	//a=b;
	a++;
	printf("%d",a);
//we cannot change value of array
}
