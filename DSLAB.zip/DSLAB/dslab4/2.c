#include<stdio.h>
/*BINARY SEARCH*/
void main()
{	
	int a[100],mid,start,end,e,n,i,f=0,c=0;

	printf("Enter the size\n");
	scanf("%d",&n);
	printf("enter the values in increasing order\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the element to search\n");
	scanf("%d",&e);
	start=0;
	end=n-1;
	mid=(start+end)/2;
	while(1)
	{
		
		c++;
		if(a[mid]==e)
		{
			f=1;
			break;
		}
		else if(e>a[mid])
			start=mid+1;
		else
			end=mid-1;

	mid=(start+end)/2;
	}
	if(f==1)
		printf("%d element found at %d position",e,mid);
	else
		printf("\nelement not found");
	printf("\n%d---comparisions",c);
}
