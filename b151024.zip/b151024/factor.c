#include<stdio.h>
void main()
{ int a,b;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
if(a%b==0)
printf("b is a factor of a");
else
printf("b is not factor of a");}
