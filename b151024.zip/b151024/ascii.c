#include<stdio.h>
void main()
{
char ch;
printf("enter a character\n");
scanf("%c",&ch);
printf("ASCII value of %c is %d",ch,ch);
}
