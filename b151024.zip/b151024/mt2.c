#include<stdio.h>
int main()
{
	int x,y=5,z=5;
	x=y==z;
	printf("%d",x);
	return 0;
}
	
