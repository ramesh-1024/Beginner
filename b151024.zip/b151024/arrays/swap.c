#include<stdio.h>
void main()
{
	int a[100],b[100],i,n;
	printf("enter the no of elements:");
	scanf("%d",&n);
	printf("enter the values:");
	for(i=0;i<n;i++)
	{
	scanf("%d",&a[i]);
	b[i]=a[i];
	}
	printf("swaped array is:\n");	
	for(i=0;i<n;i++)
	printf("%d\n",b[i]);
}
