#include<stdio.h>
void main()
{	 int a[100],i,n,c=0,s=0;
		printf("enter the number");
		scanf("%d",&n);
	printf("enter how many num u want");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[i]%2==0)
		c++;
		else
		s++;	
	}	

	printf("even count %d and odd count %d",c,s);
}
