#include<stdio.h>
void main()
{ int a[100],n,i,j,k,m,smax,fmax;
	printf("enter a number for how many no.s u want from array:");
	scanf("%d",&n);
	printf("enter the numbers:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	if(a[0]>a[1])
	{ 
		fmax=a[0];
		smax=a[1];
	}
	else
	{
		fmax=a[1];
		smax=a[0];
	}
			
	for(i=2;i<n;i++)
	{   
		if(a[i]>fmax)
		{ 
			smax=fmax;
			fmax=a[i];
			
		}
		else
		{ 
			if (a[i]>smax)
			smax=a[i];
		}
	
	}	

	printf("fmax=%d and smax=%d",fmax,smax);
}
