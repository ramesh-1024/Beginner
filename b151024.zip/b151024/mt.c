#include<stdio.h>
void main()
	
{ printf(2+"rguktbasar");
}
