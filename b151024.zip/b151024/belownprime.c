#include<stdio.h>
void main()
{ int n,c,i,k;
printf("enter any number");
scanf("%d",&n);
for(i=1;i<n;i++)
	{ 	
		c=0;		
		for(k=1;k<=i;k++)
			{ if (i%k==0)
				c++;
			}
	if(c==2)
	printf("%d\n",i);
	}


}
