#include<stdio.h>
void main()
{ int i,j;

	for(i=5;i<=0;i--)
	{ for(j=9;j>0;j++)
		{
			if(5-i<=j && 5+i>=j)
			printf("*");
			else
			printf(" ");
		}printf("\n");

	}
}
