#include<stdio.h>
#include<stdlib.h>

struct node
{
	struct emp
	{
		char id[20];
		char name[50];
		char addr[30];
		int age;
		float sal;
	}*emp;

	struct node *nxt;
};

void main()
{
	struct node *root,*temp,*p,*new,*emp;
	int i,k,a,op,m,j;
	printf("choose an option:");
	printf("1.CREATING NODES\n2.INSERT A NEW NODE\n3.DELETE A NODE USING EMPLOYEE ID\n4.DISPLAY THE LINKED LIST\n5.DISPLAY DATA OF EMPLOYEE BY USING EMP.ID\n6.EXIT\n:");
	scanf("%d",&op);
	switch(op)
	{
	case 1:
	root=(struct node*)malloc(sizeof(struct node));
	printf("enter the no.of nodes to be created:\n");
	scanf("%d",&a);
	temp=root;
	for(i=1;i<a;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
	}
	temp->nxt=NULL;
	printf("successfully created %d nodes\n",i);	
	break;
	case 2:
	root=(struct node*)malloc(sizeof(struct node));
	printf("enter the no.of nodes to be created:\n");
	scanf("%d",&a);
	temp=root;
	for(j=1;j<a;j++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
	}
	temp->nxt=NULL;
	temp=root;
	while(1)
	{
		scanf("%d",&temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	new=(struct node*)malloc(sizeof(struct node));
	printf("enter at which node i have to add the new node\n");
	scanf("%d",&m);
	for(j=1;j<m-1;j++)
	{
		temp=temp->nxt;
	}
	new->nxt=temp->nxt;
	temp->nxt=new;
	temp=root;
	while(1)
	{
		printf("%d",temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	break;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
