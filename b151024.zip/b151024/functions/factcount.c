#include<stdio.h>
int fact(int n)
{
	int i,c=0;
	for(i=1;i<n;i++)
	{
		if(n%i==0)
		{	c=c+1;
			printf("%d\t",i);
		}
	}
	printf("%d\n",c);
}
void main()
{ 	int n,c;
	printf("enter a number\n");
	scanf("%d",&n);
	fact(n);
	printf("%d",c);
}

