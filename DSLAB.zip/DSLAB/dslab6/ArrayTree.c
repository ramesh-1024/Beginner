#include<stdio.h>
#include<stdlib.h>
int a[100];
 int  create(int n)
 {
 	int i;
 	i=0;
 	while(1)
 	{
 		if(a[i]==-1)
	 	{
			a[i]=n;
	 		break;
	 	}
	 	else if(a[i]<n)
	 		i=2*i+2;
	 	else if(a[i]>n)
	 		i=2*i+1;
	}
	return 0;
}
int preorder(int k)
{
	if(a[k]!=-1)
	{
		printf("%d\t",a[k]);
		preorder(2*k+1);
		preorder(2*k+2);
	}
	return 0;
}
void inorder(int k)
{
	if(a[k]!=-1)
	{
		inorder(2*k+1);
		printf("%d\t",a[k]);
		inorder(2*k+2);
	}
}
void postorder(int k)
{
	if(a[k]!=-1)
	{
		postorder(2*k+1);
		postorder(2*k+2);
		printf("%d\t",a[k]);
	}
}
int minValueNode(int k)
{
   	int p= k;
    while (a[2*k+1]!=-1)
        p = 2*k+2;
    return p;
}
void  deldata(int d,int k)
{
	int m;
	if(a[k]==-1)
	{
		printf("no data\n");
		
	}	
	else if(d < a[k])
		deldata(d,2*k+1);
	else if(d > a[k])
		deldata(d,2*k+2);
	else
	{
		if (a[2*k+1]==-1 )
        {
             int temp = a[2*k+1];
        }
        else if (a[2*k+2] == -1)
        {
            int temp =a[2*k+2];
        }
	  else
	   {
	        int temp = minValueNode(0);
	        a[k] = a[temp];
	        m=2*k+2;
	     	 deldata(a[temp], m);
   	   }
   }
}
int main()
{
	
	int op,n,i,d;
	for(i=0;i<100;i++)
     	a[i]=-1;
	do
	{
	printf("1.insert\n2.preorder\n3.inorder\n4.postorder\n5.delete\n6.exit\n");
	printf("enter the option\n");
	scanf("%d",&op);
	switch(op)
	{
		case 1:
			printf("enter the size and values\n");
			scanf("%d",&n);
			create(n);		
			break;
		case 2:
			preorder(0);
			break;
		case 3:
			inorder(0);
			break;
		case 4:
			postorder(0);
			break;
		case 5:
			printf("enter the number to delete\n");
			scanf("%d",&d);
			deldata(d,0);
			break;
		case 6:
			printf("tq\n");
			exit(0);
	}
} while(op!=6);
 return 0;
}
