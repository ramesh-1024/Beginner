#include<stdio.h>
void main()
{
	int a[]={1,2,3,4,5};
	int *p;
	p=a;
	printf("a[0]=%d\n",a[0]);
	printf(	"*(&a)=%d\n",*(&a+1));
	printf("*p+1=%d\n",*p+1);
	printf("%d\n",*(p+2));
	printf("%d\n",*p+2);
}
	
