#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int i,op,n;
struct dnode
		{
			struct dnode *prev;
			char empid[10];
			char empname[15];
			char empadd[20];
			int empage;
			float empsalary;
			struct dnode *nxt;
		};
struct dnode* createnode(int);
void insertnode(struct dnode**);
struct dnode* deletenode(struct dnode *);
void fulldisplay(struct dnode *);
void empdisplay(struct dnode*,char *);
void main()
{
	char id[10];
	struct dnode *head,*temp,*p;
	do
	{
		printf("enter your option\n");
		printf("1-create n nodes\n2-insert node\n3-delete node\n4-display full list\n5-display a particular employee data\n6-exit\n");
		scanf("%d",&op);
		switch(op)
		{
			case 1 :
					printf("enter no. of employees\n");
					scanf("%d",&n);
					head=createnode(n);
					temp=head;
					for(i=1;;i++)
						{
							printf("\nenter the id of employee-%d : ",i);
							scanf("%s",temp->empid);
							printf("enter the name of employee-%d : ",i);
							scanf("%s",temp->empname);
							printf("enter the address of employee-%d : ",i);
							scanf("%s",temp->empadd);
							printf("enter the age of employee-%d : ",i);
							scanf("%d",&temp->empage);
							printf("enter the salary of employee-%d : ",i);
							scanf("%f",&temp->empsalary);
							if(temp->nxt==NULL)
							break;
							temp=temp->nxt;
						}
					printf("\n%d employee data stored succesfully\n",n);
					break;
			case 2 :
					insertnode(&head);
					printf("new node inserted successfully\n");
					break;
			case 3 :
					head=deletenode(head);
					printf("node deleted succesfully\n");
					break;
			case 4 :
					fulldisplay(head);
					break;
			case 5 :
					printf("enter the id of the employee\n");
					scanf("%s",id);
					empdisplay(head,id);
					break;
			case 6 :
					printf("thankyou\n");
					break;
			default :
					printf("invalid option entered\n");
		}
	}while(op!=6);
}
struct dnode* createnode(int s)
{
	struct dnode *head,*temp,*p;
	head=(struct dnode*)malloc(sizeof(struct dnode));
	temp=head;
	head->prev=NULL;
	for(i=1;i<s;i++)
		{
			p=(struct dnode*)malloc(sizeof(struct dnode));
			temp->nxt=p;
			p->prev=temp;
			temp=temp->nxt;
		}
	temp->nxt=NULL;
	return head;
}
void insertnode(struct dnode **root)
{
	int m,c=1;
	struct dnode *temp,*new;
	new=(struct dnode*)malloc(sizeof(struct dnode));
	printf("enter at which place the new node should be inserted\n");
	scanf("%d",&m);
	if(m==1)
		{
			new->nxt=*root;
			(*root)->prev=new;
			new->prev=NULL;
			*root=new;
			printf("enter the elements in new node\n");
			scanf("%s",new->empid);
			scanf("%s",new->empname);
			scanf("%s",new->empadd);
			scanf("%d",&new->empage);
			scanf("%f",&new->empsalary);
		}
	else
	{
		temp=*root;
		while(1)
			{
				if(c==m-1)
					{
						new->nxt=temp->nxt;
						new->prev=temp;
						temp->nxt=new;
						new->nxt->prev=new;
						break;
					}
				temp=temp->nxt;
				c++;
			}
		printf("enter the elements in new node\n");
		scanf("%s",new->empid);
		scanf("%s",new->empname);
		scanf("%s",new->empadd);
		scanf("%d",&new->empage);
		scanf("%f",&new->empsalary);
	}
}
struct dnode* deletenode(struct dnode* root)
{
	struct dnode *temp,*ref;
	int m,c;
	printf("enter which node should be deleted\n");
	scanf("%d",&m);
	if(m==1)
	{
		temp=root;
		root=root->nxt;
		root->prev=NULL;
		free(temp);
		return root;
	}
	else
	{
		temp=root;c=1;
		while(1)
			{
				if(c==m-1)
				break;
				temp=temp->nxt;
				c++;
			}
		ref=temp->nxt;
		temp->nxt=temp->nxt->nxt;
		temp->nxt->prev=temp;
		free(ref);
		return root;
	}
}
void fulldisplay(struct dnode *root)
{
	struct dnode *temp;
	temp=root;
	for(i=1;;i++)
		{
			printf("\ndetails of employee-%d\n",i);
			printf("%s\n",temp->empid);
			printf("%s\n",temp->empname);
			printf("%s\n",temp->empadd);
			printf("%d\n",temp->empage);
			printf("%.2f\n",temp->empsalary);
			if(temp->nxt==NULL)
			break;
			temp=temp->nxt;
		}
	while(1)
		{
			printf("\n\n\n%s\n",temp->empid);
			if(temp->prev==NULL)
			break;
			temp=temp->prev;
		}
}
void empdisplay(struct dnode *root,char *c)
{
	int r;
	struct dnode *temp;
	temp=root;
	while(1)
		{
			r=strcmp(c,temp->empid);
			if(r==0)
				{
					printf("%s\n",temp->empid);
					printf("%s\n",temp->empname);
					printf("%s\n",temp->empadd);
					printf("%d\n",temp->empage);
					printf("%f\n",temp->empsalary);
					printf("\n");
					break;
				}
			if(temp->nxt==NULL)
				{
					printf("the id didn't match with any one in the list\n");
					break;
				}
			temp=temp->nxt;
		}
}
