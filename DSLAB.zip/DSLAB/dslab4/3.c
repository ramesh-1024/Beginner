#include<stdio.h>
/*SELECTION SORTING*/
void main()
{
	int a[100],n,i,g,temp,j,k=0,min,p=0,m=0;
	printf("enter the size of array\n");
	scanf("%d",&n);
	printf("enter the values\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);	
	for(i=0;i<n-1;++i)
	{
		m++;
		min=i;
		for(j=i+1;j<n;j++)
		{
			k++;
			if(a[j]<a[min])
			min=j;
		}	
		temp=a[min];
		a[min]=a[i];
		a[i]=temp;
		printf("\npass %d\t",++p);
		for(g=0;g<n;g++)
		printf("\t%d",a[g]);
	}	
	printf("\nFinal Sorted List\n");
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
	printf("\ncomaparisions==%d\t and swaps==%d\t",m,k);
}
