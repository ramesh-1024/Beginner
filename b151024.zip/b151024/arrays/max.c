#include<stdio.h>
void main()
{	 int a[100],i,n,max=1;
		printf("enter the number");
		scanf("%d",&n);
	printf("enter how many num u want");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the numbers");
	for(i=0;i<n;i++)
	{ 		
		if(a[i]>max)
			max=a[i];
	
	}
printf("%d\t",max);
}
		
		
		
