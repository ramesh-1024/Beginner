#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *prv,*nxt;
};

void main()
{
	struct node *root,*temp,*p,*root2,*temp2,*p2;
	int i,k;
	
	root=(struct node*)malloc(sizeof(struct node));
	temp=root;
	printf("enter the no.of nodes to be created\n");
	scanf("%d",&k);
	for(i=1;i<k;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		p->prv=temp;
		temp=temp->nxt;
	
	}
	temp->nxt=root;
	root->prv=temp;
	temp=root;
	printf("enter the data into nodes:\n");
	while(1)
	{
		scanf("%d",&temp->n);
		if(temp->nxt==root)
		break;
		temp=temp->nxt;
	}
	temp=root;
	printf("enter the no.of nodes to be created\n");
	root2=(struct node *)malloc(sizeof(struct node));
	temp2=root2;
	scanf("%d",&k);
	for(i=1;i<k;i++)
	{
		p2=(struct node*)malloc(sizeof(struct node));
		temp2->nxt=p2;
		p2->prv=temp2;
		temp2=temp2->nxt;
	
	}
	temp2->nxt=root2;
	root2->prv=temp2;
	temp2=root2;
	printf("enter the data into nodes:\n");
	while(1)
	{
		scanf("%d",&temp2->n);
		if(temp2->nxt==root2	)
		break;
		temp2=temp2->nxt;
	}
	
	temp=root;
	while(temp->nxt!=root)
	{
		temp=temp->nxt;
		
	}
	temp->nxt=root2;
	temp2=root2;
	while(temp2->nxt!=root2)
	{
		temp2=temp2->nxt;
	}
	temp2->nxt=root;
	root->prv=temp2;
	temp=root;
	printf("data in double linked lists:\n"); 	
	while(1)
	{
		printf("\n%d\n",temp->n);
		if(temp->nxt==root)
		break;
		temp=temp->nxt;
		
	}
}	
				
	
	
	
	
	
	
		
		
		
	
	
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
