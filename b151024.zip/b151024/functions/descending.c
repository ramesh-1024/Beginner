#include<stdio.h>
int descending(int a,int b,int c)
{	if((a>b)&&(a>c))
	{
		printf("%d\t",a);
		if (b>c)
		printf("%d\t %d\t",b,c);
		else 
		printf("%d\t %d\t",c,b);
	}
	else if((b>a)&&(b>c))
	{
		printf("%d\t",b);
		if(a>c)
		printf("%d\t %d\t",a,c);
		else
		printf("%d\t %d\t",c,a);
	}
	else 
        {       printf("%d\t",c);
		if(a>b)
		printf("%d\t %d\t",a,b);
		else
		printf("%d\t %d\t",b,a);
        }
						
}	
void main()
{ 	int a,b,c;
	printf("enter three numbers:\n");
	scanf("%d %d %d",&a,&b,&c);
	descending(a,b,c);
	
}

