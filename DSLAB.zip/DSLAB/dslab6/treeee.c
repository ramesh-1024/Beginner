#include<stdio.h>
#include<stdlib.h>	
#include<conio.h>
struct node
{
	int n;
	struct node *lchild,*rchild;
};
struct node *root=NULL;
struct node* create(int d)
{
	struct node *q;
	q=(struct node *)malloc(sizeof(struct node));
		q->n=d;
		q->lchild=NULL;
		q->rchild=NULL;
		return q;
}
struct node *insert(struct node *root,int d)
{
	struct node *p;
	if(root==NULL)
	{
		p=create(d);
		root=p;	
	}	
	else if(d>root->n)
		root->rchild=insert(root->rchild,d);
	else if(d<root->n)
		root->lchild=insert(root->lchild,d);
	else
	{
		printf("\n Duplicate n ");
	}
	return root;
}


void preorder(struct node *root)
{
	if(root!=NULL)
	{
		printf("%3d",root->n);
		preorder(root->lchild);
		preorder(root->rchild);
	}
}

void inorder(struct node *root)
{
		if(root!=NULL)
	{
		inorder(root->lchild);
		printf("%3d",root->n);
		inorder(root->rchild);
	}
}
void postorder(struct node *root)
{
		if(root!=NULL)
	{	
		postorder(root->lchild);
		postorder(root->rchild);
		printf("%3d",root->n);
	}
}
void main()

{
	int d,op;
	while(1) 
	   {
	   	printf("\n Binary Search Tree  Operations :");
     	printf("\n\t 1) Insert \n\t 2) Preorder \n\t 3) Inorder\n\t4 ) Postorder \n\t 5) Exit");	
		printf("\n Enter your choice :");
		scanf("%d",&op);
		switch(op)	
		{
			case 1:	
				printf("\n Enter an element :");
				scanf("%d",&d);
				root=insert(root,d);	
				break;
			case 2: 	
				preorder(root);			
				break;
			case 3: 	
				inorder(root);	
				break;
			case 4: 	
				postorder(root);			
				break;
			case 5: exit(0);
		}
	}
}
