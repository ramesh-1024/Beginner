#include<stdio.h>
void main()
{	int a[100],n,i=0,t,min,j,k;
	printf("enter the no.of numbers u want from array:");
	scanf("%d",&n);
	printf("enter the a value:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		min=999999;
		for(j=i;j<n;j++)
		{
			if(a[j]<min)
			{
			min=a[j];
			k=j;		
			}
		}
	t=a[k];
	a[k]=a[i];
	a[i]=t;
	}
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
		
}
	
