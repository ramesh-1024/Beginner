#include<stdio.h>
void main()
{int b;
char a;
printf("enter a character\n");
scanf("%c",&a);
a=b;
printf("ASCII value of %c is =%d",a,b);
}
