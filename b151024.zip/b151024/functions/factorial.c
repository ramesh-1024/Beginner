#include<stdio.h>
int fact(int n ,int i)
	{
		int sum=1;
		for(i=1;i<=n;i++)
		sum=sum*i;
		return sum;
	}


void main()
{
	int a,sum,i,n;
	printf("enter the number:");	
	scanf("%d",&n);
	sum=fact(n,i);
	printf("%d",sum);
}

