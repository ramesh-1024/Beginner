#include<stdio.h>
void main()
{ 	int a[100],min=999999,gcd,f,k,n,i;
	printf("enter  a number to choose numbers from array:");
	scanf("%d",&n);
	printf("enter the numbers:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{

		if(a[i]<min)
		min=a[i];
	}
	k=1;	
	while(1)
	{
		gcd=a[i]/k;
		for(f=0,i=0;i<n;i++)
		{ 
			if(a[i]%gcd!=0)
			f=1;
		}
		if(f==0)
		{
			printf("gcd is %d\n",gcd);
			break;
		}
	k++;
	}
}				
