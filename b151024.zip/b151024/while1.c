#include<stdio.h>
void main()
{ int c=0;
while(c<20)
	{c=c+1;
printf("1.ramesh\n");
	
	}
}
