#include<stdio.h>
int n;
void swap(int *a,int *b)
{
	int z;
	z=*a;
	*a=*b;
	*b=z;
}
void quicksort(int arr[],int low,int high)
{
	int i,j,key,k;
	if(low<high)
	{
		key=arr[low];
		i=low+1,j=high;
		while(i<=j)
		{
			while((i<=j)&&(arr[i]<=key))
				i++;
			while((j>=i)&&(key<=arr[j]))
				j--;
			if(i<j)
			swap(&arr[i],&arr[j]);
		}
		swap(&arr[low],&arr[j]);
		for(i=0;i<n;i++)
			printf("%d\t",arr[i]);
		printf("\n");
		quicksort(arr,low,j-1);
		quicksort(arr,j+1,high);
	}	
}
void main()
{
	int arr[10],i;
	printf("enter the size of array\n");
	scanf("%d",&n);
	printf("enter the elements\n");
	for(i=0;i<n;i++)
	scanf("%d",&arr[i]);
	quicksort(arr,0,n-1);
	printf("the sorted array is\n");
	for(i=0;i<n;i++)
	printf("\n%d\t",arr[i]);
}


