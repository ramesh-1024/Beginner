#include<stdio.h>
void main()
{	 int a[10][10],b[10][10],sum[10][10],row,col,i,j,t,m,n;
	printf("enter the no of rows and columns:\n");
	scanf("%d %d",&row,&col);
	printf("enter the elements of the 1st matrix:\n");
	for(i=0;i<row;i++)
	{	
		for(j=0;j<col;j++)
		scanf("%d",&a[i][j]);
		printf("\n");
			
	}
	
	printf("the 2nd matrix elements are \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		scanf("%d",&b[i][j]);
		printf("\n");		
	}
	printf("subtraction of the matrices is \n");
	for(i=0;i<row;i++)
	{	
		for(j=0;j<col;j++)
		{	sum[i][j]=a[i][j]-b[i][j];
			printf("%d\t",sum[i][j]);
		}printf("\n");
	}
	
}	
