#include<stdio.h>
void main()
{ float a,b,c,d,e,f;
a=2.225;
b=1.986;
c=(float)a/b;
d=a-b;
e=a*b;
f=a+b;
printf("%f and %f is %.2f",a,b,c);
printf("\n%f and %f is %.2f",a,b,d);
printf("\n%f and %f is %.2f",a,b,e);
printf("\n%f and %f is %.2f",a,b,f);}
