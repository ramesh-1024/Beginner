#include<stdio.h>
int arm(int a)
{
	int r,sum=0,t;
	t=a;
	while(a>0)
	{ 	r=a%10;
		a=a/10;
		sum=sum+(r*r*r);
	}
	if(sum==t)
	printf("%d is an Armstrong number\n",t);
	else
	printf("%d is not an Armstrong number\n",t);
}


void main()
{
	int a,b,t,sum;
	printf("entera number:");
	scanf("%d",&a);
	arm(a);
	
}

