#include<stdio.h>
 void main()
{ int a,b,c;
	printf("enter any two numbers");
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		c=a-b;
		printf("the subtracton of %d and %d is %d\n",a,b,c);
		if(a%b==0)
		printf("%d is a factor of %d",b,a);
		else 
		printf("%d is not a factor of %d",b,a);
	}
	else
	{	c=b-a;
		printf("the subtraction of %d and %d is %d\n",a,b,c);
		if(b%a==0)
		printf("%d is a factor of %d",a,b);
		else
		printf("%d is not a factor %d",a,b);
	}
}
