#include<stdio.h>
void main()
{		 int k,m=99999999;
		printf("enter the numbers to know the min.value of those\n");
		do
		{ 	scanf("%d",&k);	
			if (k<m && k!=-1)
						
			m=k;
		}
		while(k!=-1);
		printf("the min. value of seq.is %d\n",m);

}
							
