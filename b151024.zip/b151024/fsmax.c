#include<stdio.h>
void main()
  { int a,b,k,firstmax,secondmax;
	printf("enter the numbers");
		scanf("%d",&a);
		scanf("%d",&b);
	if(a>b)
	{	firstmax=a;
		secondmax=b;
	}
	else
	{ 	firstmax=b;
		secondmax=a;
	}
		do
		{ 	scanf("%d",&k);
			
			if(k>firstmax)
				{ 	secondmax=firstmax;
					firstmax=k;
				}
			else
				{ if(k>secondmax)
				secondmax=firstmax;
				}
		}
	while(k!=-1);
printf("firstmax=%d and second max=%d",firstmax,secondmax);
  }

