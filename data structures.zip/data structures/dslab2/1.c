#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int i,op,n;
struct node
		{
			char empid[10];
			char empname[15];
			char empadd[20];
			int empage;
			float empsalary;
			struct node *nxt;
		};
struct node* createnode(int);
void insertnode(struct node**);
struct node* deletenode(struct node *);
void fulldisplay(struct node *);
void empdisplay(struct node*,char *);
void main()
{
	char id[10];
	struct node *head,*temp,*p;
	do
	{
		printf("enter your option\n");
		printf("1-create n nodes\n2-insert node\n3-delete node\n4-display full list\n5-display a particular employee data\n6-exit\n");
		scanf("%d",&op);
		switch(op)
		{
			case 1 :
					printf("enter no. of employees\n");
					scanf("%d",&n);
					head=createnode(n);
					temp=head;
					for(i=1;;i++)
						{
							printf("\nenter the id of employee-%d : ",i);
							scanf("%s",temp->empid);
							printf("enter the name of employee-%d : ",i);
							scanf("%s",temp->empname);
							printf("enter the address of employee-%d : ",i);
							scanf("%s",temp->empadd);
							printf("enter the age of employee-%d : ",i);
							scanf("%d",&temp->empage);
							printf("enter the salary of employee-%d : ",i);
							scanf("%f",&temp->empsalary);
							if(temp->nxt==NULL)
							break;
							temp=temp->nxt;
						}
					printf("\n%d employee data stored succesfully\n",n);
					break;
			case 2 :
					insertnode(&head);
					printf("new node inserted successfully\n");
					break;
			case 3 :
					head=deletenode(head);
					printf("node deleted succesfully\n");
					break;
			case 4 :
					fulldisplay(head);
					break;
			case 5 :
					printf("enter the id of the employee\n");
					scanf("%s",id);
					empdisplay(head,id);
					break;
			case 6 :
					printf("thankyou\n");
					break;
			default :
					printf("invalid option entered\n");
		}
	}while(op!=6);
}
struct node* createnode(int s)
{
	struct node *head,*temp,*p;
	head=(struct node*)malloc(sizeof(struct node));
	temp=head;
	for(i=1;i<s;i++)
		{
			p=(struct node*)malloc(sizeof(struct node));
			temp->nxt=p;
			temp=temp->nxt;
		}
	temp->nxt=NULL;
	return head;
}
void insertnode(struct node **root)
{
	int m,c=1;
	struct node *temp,*new;
	new=(struct node*)malloc(sizeof(struct node));
	printf("enter at which(node number) place the new node should be inserted\n");
	scanf("%d",&m);
	if(m==1)
		{
			new->nxt=*root;
			*root=new;
			printf("enter the elements in new node\n");
			printf("enter the id\n");
			scanf("%s",new->empid);
			printf("enter the emp name\n");
			scanf("%s",new->empname);
			printf("enter the address\n");
			scanf("%s",new->empadd);
			printf("enter the emp age\n");
			scanf("%d",&new->empage);
			printf("enter the salary\n");
			scanf("%f",&new->empsalary);
		}
	else
	{
		temp=*root;
		while(1)
			{
				if(c==m-1)
					{
						new->nxt=temp->nxt;
						temp->nxt=new;
						break;
					}
				temp=temp->nxt;
				c++;
			}
		printf("enter the elements in new node\n");
		scanf("%s",new->empid);
		scanf("%s",new->empname);
		scanf("%s",new->empadd);
		scanf("%d",&new->empage);
		scanf("%f",&new->empsalary);
	}
}
struct node* deletenode(struct node* root)
{
	struct node *temp,*ref;
	int m,c;
	printf("enter which node should be deleted\n");
	scanf("%d",&m);
	if(m==1)
	{
		temp=root;
		root=root->nxt;
		free(temp);
		return root;
	}
	else
	{
		temp=root;c=1;
		while(1)
			{
				if(c==m-1)
				break;
				temp=temp->nxt;
				c++;
			}
		ref=temp->nxt;
		temp->nxt=temp->nxt->nxt;
		free(ref);
		return root;
	}
}
void fulldisplay(struct node *root)
{
	struct node *temp;
	temp=root;
	for(i=1;;i++)
	{
		printf("\ndetails of employee-%d\n",i);
		printf("%s\n",temp->empid);
		printf("%s\n",temp->empname);
		printf("%s\n",temp->empadd);
		printf("%d\n",temp->empage);
		printf("%.2f\n",temp->empsalary);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
}
void empdisplay(struct node *root,char *c)
{
	int r;
	struct node *temp;
	temp=root;
	while(1)
		{
			r=strcmp(c,temp->empid);
			if(r==0)
				{
					printf("empid:%s\n",temp->empid);
					printf("emp name:%s\n",temp->empname);
					printf("emp address:%s\n",temp->empadd);
					printf("emp age:%d\n",temp->empage);
					printf("emp%f\n",temp->empsalary);
					printf("\n");
					break;
				}
			if(temp->nxt==NULL)
			{
				printf("the id didn't match with any one in the list\n");
				break;
			}
			temp=temp->nxt;
		}
}
