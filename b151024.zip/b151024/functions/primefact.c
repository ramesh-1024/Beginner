#include<stdio.h>
int primefact(int n)
{
	int i,c,j,d=0;
	for(i=1;i<n;i++)
	{
		if(n%i==0)
		{
			for(j=1,c=0;j<=i;j++)
			{
				if(i%j==0)
				c++;
			}
	if(c==2)
	printf("%d\t",i);	
		
		}
}
							
}	
void main()
{ 	int n,c;
	printf("enter a number\n");
	scanf("%d",&n);
	primefact(n);
	
}

