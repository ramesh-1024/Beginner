#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int top=-1;
char s[100],ip[100],op[100];
void push(char c)
{
	s[++top]=c;
}
char pop()
{
	return s[top--];
	
}
int preced(char c)
{
	switch(c)
	{
		case'*':
		case'/':
		case'%':
			return 3;
			break;
		case'+':
		case'-':
			return 2;
			break;
		case'^':
			return 4;
			break;
		case'(':
			return 1;
			break;
		
	}
}
int isanum(char c)
{
	return (c>='0'&&c<='9'?0:1);
	
}
void main()
{
	int i,k;
	printf("enter the infix expresion:\n");
	scanf("%s",ip);
	for(i=0,k=0;i<strlen(ip);i++)
	{
		if(isanum(ip[i])==0)
		op[k++]=ip[i];
		else if(ip[i]=='(')
		push(ip[i]);
		else if(ip[i]==')')
		{
			while(s[top]!='(')
			op[k++]=pop();
			pop();
		}
 		else
		{
			if(top==-1)
				push(ip[i]);
			else if(preced(ip[i])>preced(s[top]))
				push(ip[i]);
			else
			{
				while(preced(ip[i])<=preced(s[top]))
				op[k++]=pop();
				push(ip[i]);
			}
		}
	}
	while(top>=0)
	op[k++]=pop();
	op[k]='\0';
	printf("%s",op);
}
