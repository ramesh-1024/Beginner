#include<stdio.h>
void main()
{ int a,b,c;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
if (a>b)
{
c=a-b;
printf("the subtraction of %d and %d is %d",a,b,c);
}
else 
{
c=b-a;
printf ("the subtraction of %d and %d is %d",b,a,c);
}
}
