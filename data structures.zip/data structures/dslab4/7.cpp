#include<stdio.h>
#include<stdlib.h>
int f=-1,r=-1,q[100],y;
void qinsert(int q[],int n)
{
	int data,i;
	if(r==n-1)
		{
			printf("queue is overflow\n");
			exit(1);
		}	
	else
	printf("enter the %d elements\n",n);
	for(i=0;i<n;i++)
	{
		
		scanf("%d",&data);
		q[++r]=data;
	}	
	if(f==-1)
	f++;
}
int qdelete(int q[],int n)
{

	if(f==-1||f>r)
	{
			printf("queue is under flow\n");
		exit(1);
	}
		else
		y=q[f];
		f++;
		return y;
}
void qdisplay(int q[],int n)
{
	int i;	
	for(i=f;i<=r;i++)
	printf("\ndata in queue is:%d\n",q[i]);
}
	
void main()
{
	int op,n;
	do
	{
	printf("\nOPERATIONS ON QUEUE\n");
	printf("1.insert\n2.delete\n3.display\n4.exit\n choose an option\n");
	scanf("%d",&op);
	switch(op)
		{
			case 1:
				printf("Enter the size of queue\n");
				scanf("%d",&n);
				qinsert(q,n);
				break;
		case 2:
				qdelete(q,n);
				printf("\nDeleted element is %d\n",y);
				break;
		case 3:
				qdisplay(q,n);
				break;
		case 4:
				printf("Thanks for using stack\n");
				break;
		default:
				printf("Invalid option.....better luck next time(from 1-3)\n");
			
		}
	}while(op!=4);
	
}
