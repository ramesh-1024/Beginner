#include<stdio.h>
int pro(int a,int b)
{
	int c;
	c=a*b;
	return c;
}
void main()
{
	int a,b,c,k;
	scanf("%d %d",&a,&b);
	k=pro(a,b);
	printf("%d",k);
}
	
