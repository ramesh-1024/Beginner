#include<stdio.h>
void main()

{ int f,c,a,b;
	/*print farenheit table
f=0,20,......,250*/
	a=0;
	f=c;
	b=20;	
		
	for(;f<=250;)
	{	c=5*(f-32)/9;
		printf("%d\t%d\n",f,c);
		f=f+20;
	}
}
