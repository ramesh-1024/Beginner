#include<stdio.h>
#include<math.h>
int c=0;
void toh(int n,int l,int m,int r)
	{
		c++;
			if(n!=0)
		{
			toh(n-1,l,r,m);
			printf("Move Disk From Tower %d to Tower %d\n",l,r);
			toh(n-1,m,l,r);
			
		}
	}
	
	void main()
	{
		int n,twr1=1,twr2=2,twr3=3;
		printf("enter the no.of disks\n");
		scanf("%d",&n);
		toh(n,twr1,twr2,twr3);
		printf("\t%d",c/2);
	}
