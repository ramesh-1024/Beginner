#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *nxt;
};

void main()
{
	struct node *ptr,*root,*temp,*p;
	int i,k,j,a;
	
	root=(struct node*)malloc(sizeof(struct node));
	printf("enter the no.of nodes u want to create:\n");
	scanf("%d",&a);
	temp=root;
	for(i=1;i<a;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
	}
	temp->nxt=NULL;
	printf("enter the data:\n");
	temp=root;
	while(1)
	{	
		scanf("%d",&temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	while(1)
	{	
		if(temp->nxt->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	free(temp->nxt->nxt);
	temp->nxt=NULL;
	printf("after deleting last node\n");
	temp=root;
	while(1)
	{	
		printf("%d\t",temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	
}
		
	
	
	
	
	
	
			
