#include<stdio.h>
void main()
{ int a,b,i;
	printf("enter any two numbers to know their G.C.D");
scanf("%d %d",&a,&b);
	if(a>b)
	{	 if(a%b==0)
		printf("G.C.D is %d",b);
		else
		{ 	i=b/2;
			while(1)
			{	
				 if(a%i==0 && b%i==0)
				{	
					 printf(" G.C.D is %d",i);
			       		break;
				}
				
		i--;	}
			
		}
	}
	else
	{ 	if(b%a==0)
		printf("G.C.D is %d",a);
		else
		{	 i=a/2;
			while(1)
			{	 if(b%i==0 && a%i==0)
				{	
					 printf("G.C.D is %d",i);
					break;
				}
						
					
		i--;	}
		}
	}
}
