#include<stdio.h>
void main()
{ int i,n;
printf("enter any number");
scanf("%d",&n);
for(i=0;i<=n;i++)
printf("%d\n",i);
}
