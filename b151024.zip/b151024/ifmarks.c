#include<stdio.h>
void main()
{ int m;
	printf("enter the marks");
	scanf("%d",&m);
		 if(m>90)
	 		printf("A+");
			else if(m>80)
			printf("A");
			else if(m>70)
			printf("B");
			else if(m>60)
			printf("C");
			else if(m>50)
			printf("D");
			else if(m>40)
			printf("P");
		else 
		printf("FAIL");
}
