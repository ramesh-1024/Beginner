#include<stdio.h>
void main()
{	 int a[100],i,n,s=9999999,lcm,k,f;
	printf("enter the no.of numbers u want");
	scanf("%d",&n);
	printf("enter the numbers");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[i]<s)
		s=a[i];
	}
	
	while(1)
	{	for(i=0,f=0;i<n;i++)
		{
			if(a[i]%s!=0)
			f=1;
		}
		if(f==0)
		{
			printf("gcd is %d\n",s);
			break;
		}
		else
		{
			s=s-1;
		}
	}
}		 
			
			
