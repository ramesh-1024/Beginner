#include<stdio.h>
void main()
{		 int sum=0,k;
		printf("enter the numbers to make the sum\n");
		do
		{ 	scanf("%d",&k);
			if(k!=-1)
			sum=sum+k;
		}
		while(k!=-1);
	printf("the sum is %d\n",sum);
}

