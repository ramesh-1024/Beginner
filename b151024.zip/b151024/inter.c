#include<stdio.h>
void main()
{ int a,b,c;
printf("please enter any three numbers ,,,,...must and should");
scanf("%d %d %d",&a,&b,&c);
if (a>=b)
{ if (a>c)
printf("%d is the gratest number of the series",a);
else 
{if(a=b)
printf("my name is Ramesh");
else 
printf("my name is harish");}
}
else 
{if (a<c)
printf("%d is smallest among the numbers",a);
else
printf("my name is harish");}
}
