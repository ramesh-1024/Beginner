#include<stdio.h>
void fact(int n)
{
	int i;
	for(i=1;i<n;i++)
	{
		if(n%i==0)
		printf("%d\t",i);
	}
}
void main()
{ 	int n;
	printf("enter a number\n");
	scanf("%d",&n);
	fact(n);
}

