#include<stdio.h>
void main()
{int a,b,c;

scanf("%d %d",&a,&b);
if(b!=0)
{c=a/b;
printf("the division of %d and %d is %d",a,b,c);}
else
printf("we cant perform");}
