#include<stdio.h>
void main()
{
	int a[10],s,n,i,j,k,l;
	printf("enter the size of hash table\n");
	scanf("%d",&n);
	int h[n];
	for(s=0;s<n;s++)
	h[s]=-1;
	printf("enter the size of array\n");
	scanf("%d",&k);
	printf("enter the values\n");
	for(i=0;i<k;i++)
	scanf("%d",&a[i]);
	printf("\nINDEX\t|\tVALUE\t");
	for(i=0;i<k;i++)
	{
		j=a[i]%10;
		while(1)
		{
			if(h[j]==-1)
			{
				h[j]=a[i];
				break;
			}
			else
				j++;	
		}
	printf("\n%d\t|\t%d",j,h[j]);
	}	
}
