#include<stdio.h>
int prime(int n)
{	int i,k,d=0,c;
	for(i=1;d<n;i++)
	{	c=0;
		for(k=1;k<=i;k++)
		{
			if(i%k==0)
			c++;
		}
	if(c==2)
	{
		d++;
		printf("%d\t",i);
	}
	}
}
void main()
{
	int n;
	printf("enter the number:");
	scanf("%d",&n);
	prime(n);
}

