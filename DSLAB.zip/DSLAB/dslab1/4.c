#include<stdio.h>
#include<stdlib.h>
void main()
{
	int i,m;
	struct node
		{
			int n;
			struct node *nxt;
		};
	struct node *head1,*head2,*temp1,*temp2,*p,*temp;
	head1=(struct node*)malloc(sizeof(struct node));
	printf("enetr no of nodes\n");
	scanf("%d",&m);
	temp1=head1;
	for(i=1;i<m;i++)
		{
			p=(struct node*)malloc(sizeof(struct node));
			temp1->nxt=p;
			temp1=p;
		}
	temp1->nxt=NULL;
	printf("enetr the elements\n");
	temp1=head1;
	while(1)
		{
			scanf("%d",&temp1->n);
			if(temp1->nxt==NULL)
			break;
			temp1=temp1->nxt;
		}
	temp1=head1;
	temp2=head2=head1->nxt;
	while(1)
		{
			if(m%2==0)
				{
					temp1->nxt=temp2->nxt;
					if(temp1->nxt==NULL)
					break;
					temp2->nxt=temp2->nxt->nxt;
					temp1=temp1->nxt;
					temp2=temp2->nxt;
				}
			else
				{
					 temp1->nxt=temp2->nxt;
					if(temp1->nxt->nxt==NULL)
					{
						temp2->nxt=NULL;
						break;
					}
					temp2->nxt=temp2->nxt->nxt;
					temp1=temp1->nxt;
					temp2=temp2->nxt;
				}
		}
	temp=head1;
	printf("linked list 1\n");
	while(1)
		{
			printf("%d\t",temp->n);
			if(temp->nxt==NULL)
			break;
			temp=temp->nxt;
		}
	temp=head2;
	printf("\nlinked list-2\n");
	while(1)
		{
			printf(" %d\t",temp->n);
			if(temp->nxt==NULL)
			break;
			temp=temp->nxt;
		}
	printf("\n");
}
