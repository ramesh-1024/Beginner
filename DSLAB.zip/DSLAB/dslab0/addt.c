#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *nxt;
};

void main()
{
	struct node *nxt,*temp,*p,*root,*new;
	int a,i;
	root=(struct node*)malloc(sizeof(struct node));
	printf("enter the no.of nodes:");
	scanf("%d",&a);
	temp=root;
	for(i=1;i<a;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
		
	}
	temp->nxt=NULL;
	new=(struct node*)malloc(sizeof(struct node));
	printf("the new data:");//adding node at tail.
	temp=root;
	while(1)
	{	
		if(temp->nxt==NULL)
		break;
		else
		temp=temp->nxt;
	}
	temp->nxt=new;
	new->nxt=NULL;
	temp=root;
	while(1)
	{
		scanf("%d",&temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	while(1)
	{
		printf("%5d",temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
}
	
	
	
	
	
	
	
	
	
		
