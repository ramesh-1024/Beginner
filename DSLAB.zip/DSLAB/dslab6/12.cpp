#include<stdio.h>
int main()
{
	int a[100];
	printf("%d",a[5]);
	return 0;
}
