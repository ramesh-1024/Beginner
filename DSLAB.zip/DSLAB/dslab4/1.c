#include<stdio.h>
//linear search
void main()
{
	int a[100],i,n,e,f=0,c=0,k=0;
	printf("Enter the elements\nTermination Condition is-1\n");
	for(i=0;a[i-1]!=-1;i++)
		scanf("%d",&a[i]);
	printf("enter the element you want to search:\n");
	scanf("%d",&e);
	for(i=0;a[i-1]!=-1;i++)
	{
		k++;
		if(e==a[i])
		{
			f=1;
			if(f==1)
			{
				printf("element %d is found at position %d of the array:\n",e,i);\
				c++;
			}
			break;
		}
	}
	if(f==0)
	printf("entered element is not there in data\n");	
	printf("%d number repeated %d times\n",e,c);
	printf("%d---comparisions\n",k);
}
