#include<stdio.h>
void main()
{ int a,b,c;
printf("enter any two numbers");
scanf("%d %d ",&a,&b);
c=a+b;
printf("the sum of %d and %d is %d",a,b,c);}
