#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *next;
};
void main()
{
	struct node *root;
	struct node *temp;
	root=(struct node*)malloc(sizeof(struct node));
	root->next=NULL;
	root->n=11;
	temp=root;
	if(temp!=0)
	{
		while(temp->next!=0)
		{
			temp=temp->next;
		}
	}
	temp->next=(struct node*)(sizeof(struct node));
	temp=temp->next;
	temp->next=NULL;
	temp->n=9;

	temp=root;
	while(temp!=NULL)
	{
		printf("%d",temp->n);
		temp=temp->next;
	}
	
	
	
	
}
	
