#include<stdio.h>
void great(int a,int b)
{
	if (a>b)
	printf("RGUKT BASAR\n telangana ,nirmal5,504107");
	else
	printf("RGUKT NUZVIDU");

	
}

void main()
{
	int a,b;
	printf("enter two numbers:");
	scanf("%d %d",&a,&b);
	great(a,b);
}

