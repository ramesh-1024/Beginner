#include<stdio.h>
void main()
{
	int a,b,c;
	printf("enter two numbers:");
	scanf("%d %d",&a,&b);
	great(a,b);
}
int great(int a,int b)
{
	if (a>b)
	printf("RGUKT BASAR\n telangana ,nirmal5,504107");
	else
	printf("RGUKT NUZVIDU");

	return 0;
}

