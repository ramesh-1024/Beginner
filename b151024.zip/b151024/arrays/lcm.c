#include<stdio.h>
void main()
{	 int a[100],i,n,s=-99999,lcm,k,f;
	printf("enter the no.of numbers u want");
	scanf("%d",&n);
	printf("enter the numbers");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[i]>s)
		s=a[i];
	}
		k=2;lcm=s;
		while(1)
			
		{
			
			for(i=0,f=0;i<n;i++)
			{
				if(s%a[i]!=0)
				f=1;
			}
				if(f==0)
				{
					printf("LCM is %d\n",s);
					break;
				}
				else
				{
					s=lcm*k;
					
				}
	k++;	}
}
