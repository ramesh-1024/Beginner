#include<stdio.h>
#include<stdlib.h>
int f=-1,r=-1,q[100],y,n,c=0,temp;
void qinsert(int q[])
{
	int data,i,o;
	c++;
	if((r==n-1 && f==0)||r==f-1)
		{
			printf("queue is overflow\n");
			exit(1);
		}	
	else if(r==n-1)
		r=-1;
	if(c==1)
	{
		printf("enter the number of elements\n");
		scanf("%d",&o);
		temp=o;
		for(i=0;i<o;i++)
		{
			scanf("%d",&data);
			q[++r]=data;
		}
	}
	else
		scanf("%d",&q[++r]);
	if(f==-1)
	f++;
}
int qdelete(int q[])
{

	if(f==-1)	
	{
		printf("queue is under flow\n");
		exit(1);
	}	
			y=q[f];
		if(f==r)
			f=r=-1;
		else if(f==n-1)
			f=0;
		else
			f++;
		return y;
}
int qdisplay(int q[])
{
	int i;
	printf("data in queue is:\n");
	if(f<=temp-1)	
	{
		for(i=f;i<=temp-1;i++)
		printf(":%d\n",q[i]);
	}
	while(1)
	{
		if(i-1==r)
			break;
		else
		{	
			if(temp==n)
				{
					for(i=0;i<=r;i++)
					printf(":%d\n",q[i]);
					break;
				}
			printf(":%d\n",q[r]);
		break;
		}
	}
}	
int main()
{
	int op;
	printf("Enter the size of queue\n");
	scanf("%d",&n);
	do
	{
	printf("\nOPERATIONS ON QUEUE\n");
	printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n Choose an option\n");
	scanf("%d",&op);
	switch(op)
		{
		case 1:
				qinsert(q);
				break;
		case 2:
				qdelete(q);
				printf("\nDeleted element is %d\n",y);
				break;
		case 3:
				qdisplay(q);
				break;
		case 4:
				printf("Thanks for using stack\n");
				break;
		default:
				printf("Invalid option....only(from 1-3)\n");
			
		}
	}while(op!=4);
return 0;
}
