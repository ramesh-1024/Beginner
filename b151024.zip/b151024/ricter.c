#include<stdio.h>
void main()
{ 	int N;
	printf("enter the value obtained on the richter scale");
	scanf("%d",&N);
	if( N<5.0)
	printf("little or no damage");
	 else if(5.0<=N<5.5)
	printf("some damage");	
	else if ( 5.5<=N<6.5)
	printf("serious damage");
	else if(  6.5<=N<7.5)
	printf("Disaster");	
	else (N>7.5) 	
	printf("Higher.---------Catastrophe");
}
