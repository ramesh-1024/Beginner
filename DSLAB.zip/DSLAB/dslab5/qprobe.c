#include<stdio.h>
#include<math.h>
void main()
{
	int a[10],s,n,i,j,k,l;
	printf("enter the size of hash table\n");
	scanf("%d",&n);
	int h[n];
	for(s=0;s<n;s++)
	h[s]=-1;
	printf("enter the size of array\n");
	scanf("%d",&k);
	printf("enter the values\n");
	for(i=0;i<k;i++)
	scanf("%d",&a[i]);
	for(i=0;i<k;i++)
	{
		j=a[i]%10;
		while(1)
		{
			if(h[j]==-1)
			{
				h[j]=a[i];
				break;
			}
			else
			{
				j=(int)(a[i]+pow(j,2))%n;
				h[j]=a[i];
				break;	
			}	
		}
	printf("\n%d\t%d\n",j,h[j]);
	}	
}
