#include<stdio.h>
int mid(int a,int b,int c)
{
if(a>b)
	{ 
	if (a<c)
	printf("%d is middle\n",a);
	else	
		{
		if (b<c)
		printf("%d is the middle\n",c);
		else
		printf("%d is the middle\n",b);
		}
	}
else
	{
	if (b<c)
	printf("%d is the middle\n",b);
	else
		{ 
		if(a<c)
		printf("%d is the middle\n",c);
		else
		printf("%d is the middle\n",a);
		}
	}
}

void main()
{
	int a,b,c;
	printf("enter a number:\n");
	scanf("%d%d%d",&a,&b,&c);
	mid(a,b,c);
	
}

