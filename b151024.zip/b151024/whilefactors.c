#include<stdio.h>
void main()
{
int c=1,n;
printf("any number");
scanf("%d",&n);
while(c<=n)
{	if (n%c==0) 
	printf("%d\n",c);
	c=c+1;
}
}
