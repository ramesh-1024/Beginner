#include<stdio.h>
int n;
int part(int a[],int low,int high)
{
	int mid;
	if(low<high)
	{
		mid=(low+high)/2;
		part(a,low,mid);
		part(a,mid+1,high);	
	}
	merge(a,low,mid,high);
}
merge(int a[],int l,int m,int h)
{
	int i;
	printf("merged list is\n");
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
}
void main()
{
	int a[100],i,j;
	printf("Enter the size of array\n");
	scanf("%d",&n);
	printf("Enter the values\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	part(a,0,n-1);
}
