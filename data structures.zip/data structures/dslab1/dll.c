#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *prv,*nxt;
};

void main()
{
	struct node *root,*temp,*p;
	int i,k;
	
	root=(struct node*)malloc(sizeof(struct node));
	temp=root;
	temp->prv=NULL;
	printf("enter the no.of nodes to be created\n");
	scanf("%d",&k);
	for(i=1;i<k;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		p->prv=temp;
		temp=temp->nxt;
	
	}
	temp->nxt=NULL;
	temp=root;
	printf("enter the data into nodes:\n");
	while(1)
	{
		scanf("%d",&temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	while(1)
	{
		printf("%d\t",temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	
	}
}



