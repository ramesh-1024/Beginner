#include<stdio.h>
void main()
{
	int c=0,n;
printf("any number");
scanf("%d",&n);
while(c<n)
	{ printf("%d\n",c);
	c=c+1;
	}
}
