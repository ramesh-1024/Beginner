#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node
{
	char name[20];
	char id[10];
	int age;
	float sal;
	char addr[50];
	struct node *nxt;
}*top=NULL;
void push(struct node* p)
{
	printf("\npushed successfull...!\n");
	p->nxt=top;
	top=p;
}
struct node* pop()
{
	struct node  *t;
	if(top==NULL)
	{
		printf("data underflow\n");
		exit(1);
	}
	t=top;
	top=top->nxt;
	return t;
	printf("\ndetails are popped successfull...!\n");
}
void peek()
{
	printf("details on the top of the stack are\n");
	printf("%s\n%s\n%d\n%f\n%s",top->name,top->id,top->age,top->sal,top->addr);
	
}
void peep(int i)
{
	int j;
	struct node* temp;
	temp=top;
	printf("employee details in position %d of the stack is:\n",i);
	for(j=1;j<i;j++)
	temp=temp->nxt;
		printf("%s\n%s\n%d\n%f\n%s",temp->name,temp->id,temp->age,temp->sal,temp->addr);
	
}
int change(int i,struct node *new)
{
	int j;
	struct node *temp;
	temp=top;
	for(j=1;j<i;j++)
	temp=temp->nxt;
	strcpy(temp->name,new->name);
	strcpy(temp->id,new->id);
	temp->age=new->age;
	temp->sal=new->sal;
	strcpy(temp->addr,new->addr);
	printf("\ndetails successfully changed in %d position\n",i);
}
	void display()
	{
		struct node *q;
			if(top==NULL)
		{
			printf("data underflow\n");
			exit(1);
		}
		q=top;
		printf("\nemployee(s) details in stack is:\n");
		for(q=top;q!=NULL;q=q->nxt)
		printf("\n%s\n%s\n%d\n%f\n%s",q->name,q->id,q->age,q->sal,q->addr);

	}
void main()
{
	int op,i;
	struct node *p,*new;
	do
	{
		printf("\n1.PUSH\n2.POP\n3.PEEK\n4.PEEP\n5.CHANGE\n6.DISPLAY\n7.EXIT\n");
		printf("\nchoose an option from above\n");
		scanf("%d",&op);
		switch(op)
		{
			case 1:
				printf("enter the details of the employee\n");
				p=(struct node*)malloc(sizeof(struct node));
				printf("enter the name:\t");
				scanf("%s",p->name);
				printf("enter the id:\t");
				scanf("%s",p->id);
				printf("enter the age:\t");
				scanf("%d",&p->age);
				printf("enter the salary:\t");
				scanf("%f",&p->sal);
				printf("enter the address:\t");
				scanf("%s",p->addr);
				push(p);
				break;
			case 2:
				pop();
				break;
			case 3:
				peek();
				break;
			case 4:
				scanf("%d",&i);
				peep(i);
				break;
			case 5:
				new=(struct node*)malloc(sizeof(struct node));
				printf("enter new employee details\n");
				printf("enter the name:\t");
				scanf("%s",new->name);
				printf("enter the id:\t");
				scanf("%s",new->id);
				printf("enter the age:\t");
				scanf("%d",&new->age);
				printf("enter the salary:\t");
				scanf("%f",&new->sal);
				printf("enter the address:\t");
				scanf("%s",new->addr);
				printf("enter position..where to add\n");
				scanf("%d",&i);
				change(i,new);
				break;
			case 6:
				display();
				break;
			case 7:
				printf("thank you\n");
				break;
			default:
				printf("invalid option\n");
				break;
		}
	}while(op!=7);
}
