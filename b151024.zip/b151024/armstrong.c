#include<stdio.h>
void main()
{ int n,t,sum=0,r;
	printf("enter any number to check it as an armstrong number\n");
	scanf("%d",&n);
	t=n;
		while(n>0)
			{ 	r=n%10;
				n=n/10;
				sum=sum+(r*r*r);
			}
	if(sum==t)
	printf("%d is an Armstrong number",t);
	else
	printf("%d is not an Armstrong number",t);
}

