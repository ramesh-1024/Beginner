#include<stdio.h>
void main()
{		 int k,m=-999999;
		printf("enter the numbers to know the max.value of those\n");
		do
		{ 	scanf("%d",&k);	
			if (k>m)
			m=k;
		}
		while(k!=-1);
		printf("the max. value of seq.is %d\n",m);

}
							
