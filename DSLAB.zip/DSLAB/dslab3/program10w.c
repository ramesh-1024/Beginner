//8. Implement program: 7 by using Singly and Doubly linked lists on employee data, where as every NODE in Linked list stores 
//Emp_Id(String), Emp_Name(String), Emp_Address(String), Employee_Age(integer), Employee_Salary(Float). 
//Note : Include extra operaton for searching and displaying  complete data of a Employee, corresponding to the given Emp_Id.

//10. Implement Program: 8  using Circular Queue's.

#include<stdio.h>
#include<stdlib.h>
int n;
struct node
{
	char name[30];
	char id[20];
	char gen[10];
	float sal;
	char add[50];
	struct node *next;
};
struct node *head,*p,*prev,*top;
void display(struct node *head)
{
	printf("NAME     :%s",head->name);
	printf("\n");
	printf("ID       :%s",head->id);
	printf("\n");
	printf("GENDER   :%s",head->gen);
	printf("\n");
	printf("SALARY   :%f",head->sal);
	printf("\n");
	printf("ADDRESS  :%s",head->add);
	printf("\n");
	printf("\n");
}

void peek()
{
	printf("peeked employee\n");
	display(top);
}
void pop()
{
	printf("popped employee\n");
	display(top);
	if(top->next!=NULL)
	top=top->next;
	else
	printf("there are no elements\n");
}
void push(struct node *p)
{
		if(top==NULL)
		top=head=p;
		else
		top->next=p;
		top=p;
}
void main()
{
	int j,i,op;
	printf("enter the no.of employees\n");
	scanf("%d",&n);
	
	printf("enter the details\n");
	top=head=NULL;
	do{
	printf("select option\n1:insert\n2:delete\n3:peek\n4:display\n5:exit\n");
	scanf("%d",&op);
	switch(op)
	{
	case 1:
	for(i=1;i<=n;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		printf("enter the name    :");
		scanf("%s",p->name);
		printf("enter the id      :");
		scanf("%s",p->id);
		printf("enter the gender  :");
		scanf("%s",p->gen);
		printf("enter the salary  :");
		scanf("%f",&p->sal);
		printf("enter the address :");
		scanf("%s",p->add);
		printf("\n");
		push(p);
	}
		for(i=1;i<=n;i++)
		{
			display(head);
			head=head->next;
		}
		break;
	case 2:
		pop();
		break;
	case 3:
		peek();
		break;
	case 4:
		display(top);
		break;
	case 5:
		printf("thankou\n");break;
	default :
		printf("invalid\n");
	}}while(op!=5);
}
