#include<stdio.h>
void main()
{	int a[100],n,i=0,t;
	printf("enter the no.of numbers u want from array:");
	scanf("%d",&n);
	printf("enter the a value:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n/2;i++)
	{
		
	 t=a[i];
	a[i]=a[n-i-1];
	a[n-i-1]=t;
	}
	for(i=0;i<n;i++)
	printf("\n%d",a[i]);
}
