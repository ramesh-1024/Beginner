#include<stdio.h>
void main()
{int a;


printf("ASCII value of %d is %c",a,a);
}
