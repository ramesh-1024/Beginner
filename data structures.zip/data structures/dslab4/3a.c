#include<stdio.h>
int top=-1,top2=-1,s[20],p[30],temp;

void  push(int rem)
{
	s[++top]=rem;
	temp=top;
	printf("data pushed successfully\n");
}

int pop()
{
	return s[temp--];
}
 void pushtwo(int k)
 {
 	p[++top2]=k;
 	printf("pushed second time successfully\n");
 }

void main()
{
	int n,f=0,i,rem,y;
	printf("enter the number:\n");
	scanf("%d",&n);
	while(n>0)
	{
		rem=n%10;
		push(rem);
		n=n/10;
	}
	while(1)
	{
		y=pop();
		printf("%d\t ",y);
		pushtwo(y);
		if(temp<0)
		break;	
	}
	i=top;
	//printf("%d\t%d\t",top,top2);
	while(top>=0)	
	{
		if(s[top]!=p[top2])
			f=1;
		top--;
		top2--;
	}
	if(f==1)
	printf("not palindrome\n");
	else
	printf("palindrome\n");
}

