#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	char id[20];
	char name[30];
	char addr[50];
	int age;
	float sal;
	struct node* nxt;
};

void main()
{
	struct node *root,*temp,*p;
	int i,n,k;
	char eid[50];
	root=(struct node*)malloc(sizeof(struct node));
	temp=root;
	printf("enter the no.of nodes want to be created:\n");
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
	}
	temp->nxt=NULL;
	temp=root;
	printf("enter the emp data\n");
	printf("id\nname\naddress\nage\nsalary\n");
	while(1)
	{
		
		scanf("%s %s %s %d %f",temp->id,temp->name,temp->addr,&temp->age,&temp->sal);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	printf("employee data is:\n");
	while(1)
	{
		printf("%s\n%s\n%s\n%d\n%f\n",temp->id,temp->name,temp->addr,temp->age,temp->sal);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	printf("enter the id\n");
	scanf("%s",eid);
	printf("%s",eid);
	temp=root;
	w	hile(temp->nxt!=NULL)
	{
		printf("%s\n%s\n%s\n%d\n%f\n",temp->id,temp->name,temp->addr,temp->age,temp->sal);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;	
	}
	

}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
