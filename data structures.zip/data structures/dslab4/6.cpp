#include<stdio.h>
#include<string.h>
#include<math.h>

int s[100],top=-1;
char ip[100],op[100];

void push(int n)
{
	s[++top]=n;
}
int pop()
{
	return s[top--];
}

int isanum(char c)
{
	return (c>='0'&&c<='9'?0:1);
}
int main()
{
	int val,i,r,l;
	printf("ENTER THE POSTFIX EXPRESSION\n");
	scanf("%s",ip);
	for(i=0;i<strlen(ip);i++)
	{
		if(isanum(ip[i])==0)
		{
			push(ip[i]-48);
		}
		else
		{
			r=pop();
			l=pop();
			//printf("%c\t%d\t%d",ip[i],r,l);
			switch(ip[i])
			{
				case'+':
					val=l+r;
					push(val);
					break;
				case'-':
					val=l-r;
					push(val);
					break;
				case'*':
					val=l*r;
					push(val);
					break;
				case'/':
					val=l/r;
					push(val);
					break;
				case'^':
					val=pow(l,r);
					push(val);
					break;
				case'%':
					val=l%r;
					push(val);
					break;
				default:
					printf("inavlid character encountered\n");			
			}	
		}
	}
printf("the result is\t==\t%d\t",pop());
return 0;	
}

