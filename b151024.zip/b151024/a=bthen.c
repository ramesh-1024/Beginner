#include<stdio.h>
void main()
{ int a,b;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
if (a=b)
printf("RGUKT BASAR\n telangana ,nirmal5,504107");
else
printf("RGUKT NUZVIDU");}
