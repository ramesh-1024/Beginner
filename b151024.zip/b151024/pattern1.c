#include<stdio.h>
void main()
{ int i,j;

	for(i=0;i<5;i++)
	{ for(j=0;j<9;j++)
		{
			if(5-i<=j && 5+i>=j)
			printf("*");
			else
			printf(" ");
		}printf("\n");

	}
}
