#include<stdio.h>
void main()
{int a,b=1,e,f;
printf("enter any number");
scanf("%d",&a);
	while(b<=a)
	{
		 if(a%b==0)
		{	 int c=1,d=0;
			while(c<=b)
			
			{	if(b%c==0)
				d++;
				c++;
			}
				
			if(d==2)
			printf("%d is the prime factors of %d",b,a);
			}
		b++;                 
		}
}	
				
	
