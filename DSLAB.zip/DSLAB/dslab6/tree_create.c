#include<stdio.h>
#include<stdlib.h>
struct node
{
	struct node *lchild;
	int d;
	struct node *rchild;
};
struct node *root;
void main()
{
	int a[100],n,i,j;
	printf("enter the size of arry\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		insert(a[i]);
	}
/*	printf("choose an option1.Display\n2.Insert\n3.Preorder\n4.Postorder\n5.Inorder\n6.deletion\n7.exit");
	scanf("%d",&op);
	switch(op)
	{
		case 1:
			create();
			break;	
	}*/
	for(;root!=NULL;)
	printf("%d",root->d);	
	
}
void insert(int d)
{
	struct node *temp,*p,*q;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->d=d;
	temp->lchild=NULL;
	temp->rchild=NULL;
	if(root==NULL)
	 root=temp;
	else
	{
		q=root;
		p=NULL;
		while(1)
		{
			p=q;
			if(d>p->d)
			{
				q=q->lchild;
			if(q==NULL)
				p->lchild=temp;
			}
			else
			{
				 q=q->rchild;
				if(q==NULL)
				 p->rchild=temp;	
			}
		}	
	}
}
