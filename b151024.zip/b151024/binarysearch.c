#include<stdio.h>
void main()
{	int a[100],n,i=0,f,element,start,end,mid;
	printf("BINARY SEARCH\n");
	printf("enter the no.of numbers u want from array:\n");
	scanf("%d",&n);
	printf("enter the numbers in ASCENDING ORDER ONLY:\n");
	printf("the values are:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the number u want to search in the array:\n");
	scanf("%d",&element);
	start=a[0];
	end=a[n-1];
	while(start<=end)
	{	mid=(start+end)/2;	
		f=0;
		if(a[mid]==element)
		{
			f=1;
			break;		
		}
	else if(element>a[mid])
	start=mid+1;
	else
	start=mid-1;
	}
	if(f==1)
	printf("\nthe element found \n the address of the element is=%d",mid);
	else
	printf("\nthe element is not found in the series");
}
