//11.  Design, Develop and Implement a Program in C for the following operations on Deque  ( Double-Ended-Queue) using Circular Array and Circular Linked list.  
//a) void insertFirst( element);/* insert a new element at the front of the deque */ 
//b) void insertLast( element);/* insert a new element at the rear of the deque */ 
//c) removeFirst();/* remove the element at the front of the deque */   
//d) removeLast();/* remove the element at the rear of the deque */     
//e) display();//Displays all elements of Dequeue       f) Exit.

#include<stdio.h>
#include<stdlib.h>
int s[100],size,f=-1,r=-1;
void insert(int x)
{
	if((r==(size-1)&&(f==0))||((r+1)==f))
	printf("*******!!!!!!!queue is over flow!!!!!!!*******\n");
	else
	{
		if(r==size-1)
		r=0;
		else
		r++;
		s[r]=x;
		if(f==-1)
		f=0;
	}
}
int delete()
{
	int d;
	if(f==-1)
	printf("*******!!!!!!!queue is under flow!!!!!!!*******\n");
	else
	{
		d=s[f];
		if(f==r)
		{
		f=-1;r=-1;
		}
		else if(f==size-1)
		f=0;
		else
		f++;
	}
	return d;
}
int fin(int e)
{
	
	{
	r=1;
	s[r]=e;
	}
}
int lin(int e)
{
	s[r++]=e;
}
int fre()
{	int y;
	f=1;
	y=s[f];
	f++;
	return y;
}
int lre()
{	int t;
	t=s[r];
	r++;
	return t;
}
int display()
{
	int i,j;
	if(f==-1)
	printf("there are no elements to display\n");
	else
	{
		if(f>r)
		{
		for(i=f;i<size;i++)
		printf("%d\n",s[i]);
		for(j=0;j<=r;j++)
		printf("%d\n",s[i]);
		}
		else
		{
		for(i=f;i<=r;i++)
		printf("%d\n",s[i]);
		}
	}
}
int main()
{
	int op,i,e,k,o,x;
	printf("enter size of queue\n");
	scanf("%d",&size);
	do{
		printf("select option\n1:insert\n2:delete\n3:insert first\n4:insert last\n5:remove first\n6:remove last\n7:display\n8:exit\n");
		scanf("%d",&op);
		switch(op)
		{
			case 1:
				printf("enter the element you want to insert\n");
				scanf("%d",&x);
				insert(x);
				break;
			case 2:
				delete();
				break;
			case 3:
				printf("enter element\n");
				scanf("%d",&e);
				fin(e);
				break;
			case 4:
				printf("enter element\n");
				scanf("%d",&e);
				lin(e);
				break;
			case 5:
				k=fre();
				printf("%d",k);
				break;
			case 6:
				o=lre();
				printf("%d",o);
				break;
			case 7:
				display();
				break;
			case 8:
				printf("thank you\n");
				break;
			default:
				printf("thankyou\n");
				break;
		}
	}while(op!=8);
}
