#include<stdio.h>
void main()
{
	int c=0,n;
printf("any number");
scanf("%d",&n);
while(c<n)
	{ if(c%2==0)

printf("%d\n",c);
	
c=c+1;	}
}

