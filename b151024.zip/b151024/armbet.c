#include<stdio.h>
void main()
{ int n,n1,n2,t,sum=0,r;
	printf("enter two numbers to get armstrong numbers b/w them\n");
	scanf("%d %d",&n1,&n2);

	
	for(n=n1;n<=n2;n++)
		{	 t=n;sum=0;
		while(t>0)
				{ r=t%10;
				t=t/10;
				sum=sum+(r*r*r);			

				}
		if(sum==n)
	printf("%d\t",n);
	
		}
		
}
				
				
					
			
