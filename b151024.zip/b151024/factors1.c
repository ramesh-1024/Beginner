#include<stdio.h>
void main()
{	 int a[100],i,n,k;
	printf("enter the number of numbers u want");
	scanf("%d",&n);
	printf("enter the numbers");
	
		for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
{
	 for(k=1;k<=a[i];k++)
	{	if(a[i]%k==0)
		printf("%d is  the factor of %d\n",k,a[i]);
	}
}
}

