#include<stdio.h>
#include<stdlib.h>
int f=-1,r=-1,q[100];
void qinsert(int s,int n)
{
	if((r==s-1 && f==0)||r==f-1)
		{
			printf("queue is overflow\n");
			//exit(1);
		}	
	else if(r==s-1)
	   r=0;
	else
	   q[++r]=n;	
	if(f==-1)
	   f++;
}
int qdelete(int s)
{
  int y;
	if(f==-1)	
	{
		printf("queue is under flow\n");
		//exit(1);
	}	
	  y=q[f];
	if(f==r)
		f=r=-1;
	else if(f==s-1)
	    f=0;
	else
        f++;
		return y;
}
void qdisplay(int s)
{
	int i;
	 printf("data in queue is:\n");	
	 if(f<=r)
	 {
  		for(i=f;i<=r;i++)
     	printf(":%d\n",q[i]);
     }
     else
     {
     	for(i=f;i<s;i++)
     	  printf("%d\t",q[i]);
     	for(i=0;i<=r;i++)
     	  printf("%d\t",q[i]);
	}
}
	
int main()
{
	int op,s,n,y;
	printf("enter the size of the q\n");
	scanf("%d",&s);
	do
	{
	printf("\nOPERATIONS ON QUEUE\n");
	printf("1.insert\n2.delete\n3.display\n4.exit\n choose an option\n");
	scanf("%d",&op);
	switch(op)
		{
			case 1:
				printf("enter the number\n");
				scanf("%d",&n);
				qinsert(s,n);
				break;
		case 2:
				y=qdelete(s);
				printf("\nDeleted element is %d\n",y);
				break;
		case 3:
				qdisplay(s);
				break;
		case 4:
				printf("Thanks for using queue\n");
				break;
		default:
				printf("Invalid option.....better luck next time(from 1-3)\n");
			
		}
	}while(op!=4);
return 0;	
}
