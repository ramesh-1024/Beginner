#include<stdio.h>
void main()
{ int i=1,c,k,n;
printf("enter any number");
scanf("%d",&n);
	while(i<=n)
	{ 
			 k=1;c=0;
				while(k<=i)
				{  if(i%k==0)
				   {	c++;
					k++;
					
					}
				}
i++;
			if (c==2)
			printf("%d",i);
			
	}
}
