#include<stdio.h>
int fsmax(int a,int b)
{	
	int firstmax,secondmax,k;

	if(a>b)
	{	firstmax=a;
		secondmax=b;
	}
	else
	{ 	firstmax=b;
		secondmax=a;
	}
		do
		{ 	scanf("%d",&k);
			
			if(k>firstmax)
			{ 	secondmax=firstmax;
					firstmax=k;
			}
			else
			{	 if(k>secondmax)
				secondmax=firstmax;
			}
		}
		while(k!=-1);
		printf("firstmax=%d and second max=%d",firstmax,secondmax);
  	}

void main()
{ 	int a,b,c;
	printf("enter three numbers:\n");
	scanf("%d %d",&a,&b);
	fsmax(a,b);
	
}

