#include<stdio.h>
void main()
{	 int a[100],i,n;
		printf("enter the number");
		scanf("%d",&n);
	printf("the numbbers are");
	for(i=0;i<n;i++)
	
	{	scanf("%d",&a[i]);
	if(a[i]%2==0)
	printf("%d\t",a[i]);
		
	}	

}
