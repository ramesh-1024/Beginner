#include<stdio.h>
void main()
{ int n,i=1,k,p=1;
printf("enter the number ");
scanf("%d",&n);
	while(p*i<=n)
	{ p=p*i;
	if(p<=n)
printf("%d\t",p);
i++;	}

}
