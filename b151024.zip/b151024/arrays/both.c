#include<stdio.h>
void main()
{	 int a[100],b[100],f,n,i;
	printf("enter the no.of numbers u want:");
	scanf("%d",&n);
	printf("enter the 1st ARRAY values:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the s ARRAY values:");
	for(i=0;i<n;i++)
	scanf("%d",&b[i]);
	for(i=0,f=0;i<n;i++)
	{	
		if(a[i]!=b[i])
		f=1;
	}	
	if(f==0)
	printf("ARRAYS ARE EQUAL\n");
	else
	printf("ARRAYS ARE NOT EQUAL\n");
	
}
		
//program for checking whether the values of both the arrays are equal or not
