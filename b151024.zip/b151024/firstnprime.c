	
#include<stdio.h>
void main()
{ 
	int n,c,d=1,i,k;
	printf("enter any number");
	scanf("%d",&n);
	for(i=1;d<=n;i++)
	{ 	
		c=0;		
		for(k=1;k<=i;k++)
		{ 
			if (i%k==0)
			c++;
	
		}		
	
	if(c==2)
	
		{
			d++;
			printf("%d\n",i);
		}
	}
}
