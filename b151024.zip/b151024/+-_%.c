#include<stdio.h>
void main()
{	int a,b,c,d,e,f;
	printf("enter any two numbers");
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		c=a-b;
		d=a+b;
		e=a*b;
		f=a/b;
		printf("the minus of %d and %d is %d\n",a,b,c);
		printf("the addition of %d and %d is %d\n",a,b,d);
		printf("the product of %d and %d is %d\n",a,b,e);
		printf("the division of %d and %d is %d\n",a,b,f);
		if(a%b==0)
		printf("%d is a factor of %d",b,a);
		else 
		printf("%d is not a factor of %d",b,a);
	}
	else
	{
		c=b-a;
		d=b+a;
		e=b*a;
		f=b/a;
		printf("the minus of %d and %d is %d\n",a,b,c);
		printf("the addition of %d and %d is %d\n",a,b,d);
		printf("the product of %d and %d is %d\n",a,b,e);
		printf("the division of %d and %d is %d\n",a,b,f);
		if(b%a==0)
		printf("%d is a factor of %d",a,b);
		else("%d is not a factor %d",a,b);
	}
}
