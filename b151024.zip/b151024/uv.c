#include<stdio.h>
void main()
{ 
printf("every one knows 2+2=%d\n",2+2);
return 0;
}
