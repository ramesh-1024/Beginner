#include<stdio.h>
void main()
{
	int c=1,n,b=0;
	printf("enter any number");
	scanf("%d",&n);
	while(c<=n)
	{ 
		if(n%c==0)
		{
			b=b+1;
			printf("%d\n",c);
		}
		c=c+1;
	}
	printf("the no.of.factors of %d is %d",n,b);
}
