#include<stdio.h>
void main()
{
	int c=1,n,b=0;
	printf("enter any number");
	scanf("%d",&n);
	while(c<=n)
	{	 if(n%c==0)
		b=b++;
		c=c++;
	printf("%d\n",c);
	}
printf("the no.of.factors of %d is %d",n,b);}
