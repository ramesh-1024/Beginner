#include<stdio.h>
int belowprime(int n)
{
	int i,c,j,k,d=0;
	for(i=1;d<n;i++)
	{ 	
		c=0;		
		for(k=1;k<=i;k++)
			{ if (i%k==0)
				c++;
			}
	if(c==2)
	{
	d++;
	printf("%d\n",i);
	}

}
							
}	
void main()
{ 	int n,c;
	printf("enter a number\n");
	scanf("%d",&n);
	belowprime(n);
	
}

