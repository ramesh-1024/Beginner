#include<stdio.h>
int sub(int a,int b)
{
	int c;
	c=a-b;
	return c;
}
void main()
{
	int a,b,c,k;
	scanf("%d %d",&a,&b);
	k=sub(a,b);
	printf("%d",k);
}
	
