#include<stdio.h>
#include<stdbool.h>
void main()
{
	int a=122,n=12,c,b;
	
	//if(a==n)
	//printf("%d\n",true);
	//else
	//printf("%d\n",false);
	//c=false;
	//b=true;
	//printf("%d\t%d",c,b);
	c=0;
	for(printf(6+"rgukt basar\n");c<10;printf("hai\n"))
	c++;
	switch(printf("helloworld"));
	while(!1)
	printf("@");
	
}
