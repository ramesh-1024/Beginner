#include<stdio.h>
#include<stdlib.h>

	struct node
	{
		int n;
		struct node *nxt;
	};
	
void main()
{
	struct node *root1,*root2,*temp1,*temp2,*p,*q;
	int s,t,i,j;
	root1=(struct node*)malloc(sizeof(struct node));
	printf("no.of nodes\n");
	scanf("%d",&s);
	temp1=root1;
	for(i=1;i<s;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp1->nxt=p;
		temp1=temp1->nxt;
	}
	temp1->nxt=root1;
	temp1=root1;
	printf("enter the detais:\n");
	while(1)
	{
		scanf("%d",&temp1->n);
		if(temp1->nxt==root1)
		break;
		temp1=temp1->nxt;
	}
	root2=(struct node*)malloc(sizeof(struct node));
	printf("enter the noof.nodes in 2nd list\n");
	scanf("%d",&t);
	temp2=root2;
	for(j=1;j<t;j++)
	{
		q=(struct node*)malloc(sizeof(struct node));
		temp2->nxt=q;
		temp2=temp2->nxt;
	}
	temp2->nxt=root2;
	temp2=root2;
	printf("enter the data:\n");
	while(1)
	{
		scanf("%d",&temp2->n);
		if(temp2->nxt==root2)
		break;
		temp2=temp2->nxt;
	}
	temp1->nxt=root2;
	temp2->nxt=root1;
	temp1=root1;
	printf("after concatenation:\n");
	while(1)
	{
		printf("%d\n",temp1->n);
		temp1=temp1->nxt;
		if(temp1==root1)
		break;
	}
}
