#include<stdio.h>
main()
{ int a,b;
printf("enter any two numbers");
scanf("%d %d",&a,&b);
if(a>b)
{if(a%b==0)
printf("b is a factor of a");
else 
printf("b is not a factor of a");}
else
{if(b%a==0)
printf("a is a factor of b");
else("a is not a factor of b");}
}
