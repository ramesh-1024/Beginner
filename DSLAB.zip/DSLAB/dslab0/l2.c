#include<stdio.h>
#include<stdlib.h>

	struct node
	{
		int n;
		struct node *nxt;
	};
	
void main()
{
	struct node *root1,*root2,*temp1,*temp2,*p,*q;
	int s,t,i,j;
	root1=(struct node*)malloc(sizeof(struct node));
	printf("\nenter the no.of nodes in linked list 1:\n");
	scanf("%d",&s);
	temp1=root1;
	for(i=1;i<s;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp1->nxt=p;
		temp1=temp1->nxt;
	}
	temp1->nxt=NULL;
	printf("\n\nenter the data in linked list 1\n");
	temp1=root1;
	while(1)
	{
		scanf("%d",&temp1->n);
		if(temp1->nxt==NULL)
		break;
		temp1=temp1->nxt;
	}
	temp1=root1;
	printf("the data in linked list 1\n");
	while(1)
	{
		printf("%5d",temp1->n);
		if(temp1->nxt==NULL)
		break;
		temp1=temp1->nxt;
	}
	root2=(struct node*)malloc(sizeof(struct node));
	printf("\n\nenter the no.of nodes in linked list 2:\n");
	scanf("%d",&t);
	temp2=root2;
	for(j=1;j<t;j++)
	{
		q=(struct node*)malloc(sizeof(struct node));
		temp2->nxt=q;
		temp2=temp2->nxt;
	}
	temp2->nxt=NULL;
	printf("\n\nenter the data in linked list 2\n");
	temp2=root2;
	while(1)
	{
		scanf("%d",&temp2->n);
		if(temp2->nxt==NULL)
		break;
		temp2=temp2->nxt;
	}
	temp2=root2;
	printf("\n\ndata in linked list 2\n");
	while(1)
	{
		printf("%5d",temp2->n);
		if(temp2->nxt==NULL)
		break;
		temp2=temp2->nxt;
	}
	temp1=root1;
	//temp2=root2;
	while(1)
	{
		if(temp1->nxt==NULL)
		break;
		temp1=temp1->nxt;
	}
	temp1->nxt=root2;
	printf("\n\nthe data after adding 2 linked lists\n");
	temp1=root1;
	printf("the data in linked lists\n");
	while(1)
	{
		printf("%5d",temp1->n);
		if(temp1->nxt==NULL)
		break;
		temp1=temp1->nxt;
	}	
		
		
}
