#include<stdio.h>
void main()
{ int a=0,b;
printf("enter any  number");
scanf("%d",&b);
for(;a<b;)
{if(a%2!=0)
printf("%d\n",a);
a=a+1;
}
}
