#include<stdio.h>
void main()
{ int a,b,i;
	printf("enter any two numbers for their L.C.M");
	scanf("%d %d",&a,&b);
if(a>b)
	{ 	i=1;

		while(1)
			{ if(a*i%b==0)
				{ printf("L.C.M. is %d",a*i);
					break;			
				}

			i++;	}

	}
else
	{ 	i=1;
		while(1)
			{ if (b*i%a==0)
				{ printf("L.C.M.is %d ",b*i);
					break;
			
				}

		i++;	}
	
	}
}			
	
