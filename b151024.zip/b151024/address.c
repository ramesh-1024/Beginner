#inlude<stdio.h>
void main()
{
printf(" My name is Ramesh\n");
printf("From\nH.NO 6-19\nVill&Mandl:Eligaid\nDist:Peddapalli\nPIN:505525\Mobile:8008590462);}

