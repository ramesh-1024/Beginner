#include<stdio.h>
void main()
{ int a=0,b;
printf("enter any  number");
scanf("%d",&b);
while(a<b)
{ 
printf("%d\n",b-a);
a=a+1;
}
}
