#include<stdio.h>
int gcd(int n1,int n2)
{
	if (n2%n1==0)
	printf("%d",n1);
	else
	return gcd(n2%n1,n1);
}
void main()


{
 	int n1,n2;
	scanf("%d %d",&n1,&n2);
	gcd(n1,n2);
	
}

