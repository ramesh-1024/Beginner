#include<Stdio.h>
void main()
{ int i=1,k,n,c;

printf("enter any number");
scanf("%d",&n);
while(l<=n)
{ 
	if(n%i==0)
	{	int k=0;c=1;
		while(k<=i)
		{ 	 if(i%k==0)
				 c++;
				 k++;
		}
	if (c==2)
	printf("%d is prime factors of %d\n",i,n);
	}
		i++;
}

}
