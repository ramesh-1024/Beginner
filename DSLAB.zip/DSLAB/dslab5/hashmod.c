#include<stdio.h>
void main()
{
	int a[10],hs,i,k,n,m;
	printf("Enter the size of hash table\n");
	scanf("%d",&hs);
	int h[hs];
	printf("enter the array size\n");
	scanf("%d",&n);
	printf("enter the values\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("HASH TABLE IS\nINDEX\t|VALUE\t\n");
	for(i=0;i<n;i++)
	{
		m=a[i]%hs;//m=index of hash table
		h[m]=a[i];
		printf(": %d\t|%d\t\n",m,h[m]);		
	}
}
