#include<stdio.h>
int ascen(int a,int b,int c)
{
	if((a<b)&&(a<c))
	{
		printf("%d\t",a);
		if (b>c)
		printf("%d\t %d\t",c,b);
		else 
		printf("%d\t %d\t",b,c);
	}
	else if((b<a)&&(b<c))
	{
		printf("%d\t",b);
		if(a>c)
		printf("%d\t %d\t",c,a);
		else
		printf("%d\t %d\t",a,c);
	}
	else 
	{	printf("%d\t",c);
		if(a>b)
		printf("%d\t %d\t",b,a);
		else
		printf("%d\t %d\t",a,b);
	}
	return 0;
							
}	
void main()
{ 	int a,b,c;
	printf("enter a number\n");
	scanf("%d%d%d",&a,&b,&c);
	ascen(a,b,c);
	
}

