#include<stdio.h>
#include<stdlib.h>

struct node
{
	int n;
	struct node *nxt;
};

void main()
{
	struct node *nxt,*temp,*p,*root,*new,*t,*k;
	int a,i,f;

	root=(struct node*)malloc(sizeof(struct node));
	printf("enter the no.of nodes:");
	scanf("%d",&a);
	temp=root;
	for(i=1;i<a;i++)
	{
		p=(struct node*)malloc(sizeof(struct node));
		temp->nxt=p;
		temp=temp->nxt;
		
	}
	temp->nxt=NULL;
	temp=root;
	printf("enter the data\n");
	while(1)
	{
		scanf("%d",&temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	temp=root;
	t=temp;
	temp=temp->nxt;
	k=temp->nxt;
	while(1)
	{
		temp->nxt=t;
		t=temp;
		if(f==1)
		break;
		temp=k;
		if(temp->nxt!=NULL)
			k=k->nxt;
		if(temp->nxt==NULL)
		f=1;
		
		
	}
	root->nxt=NULL;
	root=temp;
	temp=root;
	printf("linked list in reverse is:\n");
	while(1)
	{
		printf("%d\t",temp->n);
		if(temp->nxt==NULL)
		break;
		temp=temp->nxt;
	}
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
		
