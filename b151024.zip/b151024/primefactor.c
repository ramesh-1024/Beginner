#include<stdio.h>
void main()
{ i=1;
printf("enter any number");
scanf("%d",&n);
	while(i<=n)
	{ 
		if(n%i==0)
			{ k=1;c=0;
				while(k<=i)
				{  if(i%k==0)
					c++;
					k++;
					}
			if (c==2)
			printf("%d is the prime factor of %d",i,n);
			}
	}
}
