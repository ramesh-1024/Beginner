#include<stdio.h>
void main()
{ int a[100],n,i,j,k,m,smin,fmin;
	printf("enter a number for how many no.s u want from array:");
	scanf("%d",&n);
	printf("enter the numbers:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	if(a[0]<a[1])
	{ 
		fmin=a[0];
		smin=a[1];
	}
	else
	{
		fmin=a[1];
		smin=a[0];
	}
			
	for(i=2;i<n;i++)
	{   
		if(a[i]<fmin)
		{ 
			smin=fmin;
			fmin=a[i];
		}
		else
		{ 
			if (a[i]<smin)
			smin=a[i];
		}
	
	}	

	printf("fmin=%d and smin=%d",fmin,smin);
}
