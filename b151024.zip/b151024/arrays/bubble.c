#include<stdio.h>
void main()
{
	int a[100],n,i,j,k,t;
	printf("enter the no.of values from array:");
	scanf("%d",&n);
	printf("enter the values:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		for(j=1;j<n-i;j++)
		{
			if(a[j]<a[j-1])
			{
				t=a[j];
				a[j]=a[j-1];
				a[j-1]=t;
				
			}
		
		}
	
	}
	printf("sorting is:\n");
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
}

