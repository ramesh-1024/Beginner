#include<stdio.h>
void main()
{ int a,b,c;
printf("enter any three numbers");
scanf("%d %d %d",&a,&b,&c);

if(a<b)
		{ if(a<c)
		printf("%d is small",a);
		else
			{	if(b<c)
			printf("%d is small",b);
			else
			printf("%d is the small",c);

			}
	}
else
		{ if(b<c)
	        printf("%d is the smallest",b);
		else
			{ if(a<c)
			printf("%d is small",c);
			else
			printf("%d is small",a);
			}				
	}
}
