#include<stdio.h>
void main()
{	int a[100],n,i=0,f,element;
	printf("enter the no.of numbers u want from array:");
	scanf("%d",&n);
	printf("enter the a value:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the number u want to search in the array:");
	scanf("%d",&element);
	for(i=0;i<n;i++)
	{
		if(a[i]==element)
		{ f=1;
		break;
		}
	}
	if(f==1)
	{
		printf("element found in the array");
		printf("\n the address of the element is %d",i);
	 							
	}
	else
	printf("the element is not found");
}									
