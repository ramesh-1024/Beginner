#include<stdio.h>
int y=1,t=0;
void radix(int arr[],int size)
{
	int a[10][10],arr1[10],m,n,i,j,k,top[10],x=0;
	for(m=0;m<10;m++)
	{
		top[m]=-1;
	}
	for(m=0;m<=size;m++)
	{
		arr1[m]=arr[m];
		for(i=1;i<y;i++)
		arr1[m]=arr1[m]/10;
			k=arr1[m]%10;
			a[k][++top[k]]=arr[m];
	}	
	for(m=0;m<10;m++)
	{
		for(n=0;n<=top[m];n++)
		arr[x++]=a[m][n];
	}
	printf("\npass %d\n",++t);
	for(m=0;m<=size;m++)
	printf("%d\t",arr[m]);
	if(y<5)
	{
		y++;
		radix(arr,size);
	}
}
void main()
{
	int arr[10],i,n;
	printf("enter no of elements\n");
	scanf("%d",&n);
	printf("enter the elements\n");
	for(i=0;i<n;i++)
	scanf("%d",&arr[i]);
	radix(arr,n-1);
	printf("\nthe sorted array is\n");
	for(i=0;i<n;i++)
	printf("%d\t",arr[i]);	
	
}
