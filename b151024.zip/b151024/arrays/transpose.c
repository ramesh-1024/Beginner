#include<stdio.h>
void main()
{	 int a[10][10],c[10][10],row,col,i,j,t,m,n;
	printf("enter the no of rows and columns:\n");
	scanf("%d %d",&row,&col);
	printf("enter the elements of the matrix:\n");
	for(i=0;i<row;i++)
	{	
		for(j=0;j<col;j++)
		scanf("%d",&a[i][j]);
		printf("\n");	
	}
	printf("the matrix is \n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		printf("%d\t",a[i][j]);
		printf("\n");
	}
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
		c[j][i]=a[i][j];
		}
	}
	printf("transpose of the matrix is:\n");
	for(i=0;i<col;i++)
	{
		for(j=0;j<row;j++)
		{
		c[j][i]=a[i][j];
		printf("%d\t",c[i][j]);
		}printf("\n");
	}	
}
