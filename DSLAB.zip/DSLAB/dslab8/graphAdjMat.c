#include<stdio.h>
#include<stdlib.h>
struct graph
{
	int v;
	int e;
	int **adj;
};
int main()
{
	int i,m,n;
	struct graph *g;
	g=(struct graph*)malloc(sizeof(struct graph));
	scanf("Numder of vertices;%d,Number of edges:%d",&g->v,&g->e);
	g->adj=malloc(sizeof(g->v)*(g->v));
	for(m=0;m<g->v;m++)
	 for(n=0;n<g->v;n++)
	  g->adj[n][n]=0;
	for(i=0;i<g->e;i++)
	{
	 scanf("reading an edge:%d %d",&m,&n);
	 g->adj[m][n]=1;
	 g->adj[n][m]=1;
	}
	return 0;
}
