#include<stdio.h>
void main()
{ 	int i=10;
	float f=22;
	char c=A;
printf("%d\t %d\t %d\t",sizeof(i/2),sizeof(f/2),sizeof(c/2));
}
